title: LeetCode最大子序和
date: '2018-08-18 23:41:04'
updated: '2019-07-21 09:40:15'
tags: [LeetCode]
permalink: /articles/2018/08/18/1534606864012.html
---
![](https://img.hacpai.com/bing/20180726.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、题目

[LeetCode地址](https://leetcode-cn.com/submissions/detail/6062154/)

      给定一个整数数组 nums ，找到一个具有最大和的连续子数组（子数组最少包含一个元素），返回其最大和。

      示例:

      输入: [-2,1,-3,4,-1,2,1,-5,4],
      输出: 6
      解释: 连续子数组 [4,-1,2,1] 的和最大，为 6。

      进阶:

      如果你已经实现复杂度为 O(n) 的解法，尝试使用更为精妙的分治法求解。

### 二、分析

　    该题利用了五大算法之二：动态规划算法

#### 1、基本概念

      动态规划过程是：每次决策依赖于当前状态，又随即引起状态的转移。一个决策序列就是在变化的状态中产生出来的，所以，这种多阶段最优化决策解决问题的过程就称为动态规划。

#### 2、基本思想与策略

      基本思想与分治法类似，也是将待求解的问题分解为若干个子问题，按顺序求解子阶段，前一子问题的解，为后一子问题的求解提供了有用的信息。在求解任一子问题时，列出各种可能的局部解，通过决策保留那些有可能达到最优的局部解，丢弃其他局部解。依次解决各子问题，最后个子问题就是初始问题的解。

具体请自行百度

### 三、Java代码

```java
public static int maxSubArray(int[] nums) {
        int[] dp = new int[nums.length];
        dp[0] = nums[0];
        int max = dp[0];
        for (int i = 1; i < nums.length; i++) {
            dp[i] = Math.max(nums[i] + dp[i - 1], nums[i]);
            max = Math.max(max, dp[i]);
        }
        return max;
}
```

### 四、提交结果

![53](https://img.algerfan.cn/blog/image/20190619/2cbd7261bac04a4496cd10c2715c192f.png)