title: （6）Spring Boot使用docker部署（阿里云镜像服务）
date: '2019-10-23 12:07:28'
updated: '2019-10-29 20:53:44'
tags: [docker]
permalink: /articles/2019/10/23/1571803648224.html
---
![](https://img.hacpai.com/bing/20171215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

之前了解过docker的简单使用，却一直没有将项目使用docker部署，听了大佬的建议，现全部改为docker部署，虽然比较简单😂，但还是要分享给其他小伙伴 。

Windows docker下载地址：https://hub.docker.com/?overlay=onboarding

## 一、创建镜像仓库

进入阿里云镜像服务：https://cr.console.aliyun.com/cn-hangzhou/instances/repositories

首先创建镜像仓库，并选择本地仓库

![docker部署1.png](https://img.algerfan.cn/blog/image/20191023/0fbd9499798e4665a9c907ec41e5659f.png)

![docker部署2.png](https://img.algerfan.cn/blog/image/20191023/72e0435c42124702aef8143c2eb528ef.png)

## 二、构建

然后点击管理，可以看到操作指南

![docker部署3.png](https://img.algerfan.cn/blog/image/20191023/242031bdbd8845cb8ff0ff9b42ae7bbd.png)

### 1.Dockerfile

项目中新建文件Dockerfile，添加以下内容，修改为自己的项目名

```
FROM openjdk:8
ADD target/Picture-Bed-1.0-SNAPSHOT.jar picture_bed.jar
ENTRYPOINT ["java","-Djava.security.egd=file:/dev/./urandom","-jar","/picture_bed.jar"]
```

### 2.打包构建
`mvn clean package -Dmaven.test.skip=true`
`docker build -t registry.cn-hangzhou.aliyuncs.com/algerfan/picture_bed .`

### 3.推送到阿里云

首次使用先将docker登录到阿里云镜像
`docker login --username=algerfan@163.com registry.cn-hangzhou.aliyuncs.com`

然后推送
`docker push registry.cn-hangzhou.aliyuncs.com/algerfan/picture_bed:1.0`

如果本地镜像名称不正常，可以先重命名后再推送
`docker tag [ImageId] registry.cn-hangzhou.aliyuncs.com/algerfan/picture_bed:1.0`

## 三、使用镜像

在需要使用镜像的服务器上，拉取镜像，并运行。

### 1.拉取镜像

`docker pull registry.cn-hangzhou.aliyuncs.com/algerfan/picture_bed:1.0`

### 2.查看镜像

`docker image ls`

### 3.运行

`docker run --name picture_bed -p 9999:9999 -d registry.cn-hangzhou.aliyuncs.com/algerfan/picture_bed:1.0`


