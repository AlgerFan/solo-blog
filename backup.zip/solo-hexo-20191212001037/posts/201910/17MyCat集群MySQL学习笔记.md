title: （17）MyCat 集群——MySQL学习笔记
date: '2019-10-20 10:35:25'
updated: '2019-10-29 20:53:54'
tags: [MySQL]
permalink: /articles/2019/10/20/1571538925879.html
---
![](https://img.hacpai.com/bing/20180614.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 一、MyCat  配置数据库集群

所有的集群配置，都必须配置多主多从模式。即多个 master 节点相互之间配置主从。如：master1 和 slave1 为第一组主从，master2 和 slave2 为第二组主从，master1 和 master2 互为对方的主/从。

![mycat 集群 1.png](https://img.algerfan.cn/blog/image/20191020/511e8ec231f84bf8a278771ad80caa8c.png)

注意 ： crc32slot 分片规则，在使用的时候，要求必须先设置好分片规则，再启动 mycat 。如果先启动了 mycat ，再设置分片规则，会 导 致 分 片 规 则 失 效 。需 要 删 除 conf 目录中的 ruledata 子目录 。 ruledata 目 录 中 会 记 录 crc32slot 的 分片节点，日志文件命名规则为 crc32slot_ 表。

```xml
<?xml version="1.0"?>
<!DOCTYPE mycat:schema SYSTEM "schema.dtd">
<mycat:schema xmlns:mycat="http://io.mycat/">
    <schema name="TESTDB" checkSQLschema="false" sqlMaxLimit="100">
    	<table name="tb_user" dataNode="dn1,dn2,dn3" rule="crc32slot" />
    </schema>
    <dataNode name="dn1" dataHost="localhost1" database="db1" />
    <dataNode name="dn2" dataHost="localhost1" database="db2" />
    <dataNode name="dn3" dataHost="localhost1" database="db3" />
    <dataHost name="localhost1" maxCon="1000" minCon="10" balance="1" writeType="0" dbType="mysql" dbDriver="native" switchType="1" slaveThreshold="100">
        <heartbeat>select user()</heartbeat>
        <writeHost host="hostM1" url="59.69.165.38:3306" user="root" password="123456">
        	<readHost host="hostS1" url="59.69.165.50:3306" user="root" password="123456" />
        </writeHost>
        <writeHost host="hostM2" url="59.69.165.39:3306" user="root" password="123456">
        	<readHost host="hostS2" url="59.69.165.51:3306" user="root" password="123456" />
        </writeHost>
    </dataHost>
</mycat:schema>
```

缺陷 ：可能有 IO 延迟问题 。

## 二、数据库集群负载策略

### 第一种配置方案：

```xml
<?xml version="1.0"?>
<!DOCTYPE mycat:schema SYSTEM "schema.dtd">
<mycat:schema xmlns:mycat="http://io.mycat/">
    <schema name="TESTDB" checkSQLschema="false" sqlMaxLimit="100">
    	<table name="tb_user" dataNode="dn1,dn2,dn3" rule="crc32slot" />
    </schema>
    <dataNode name="dn1" dataHost="localhost1" database="db1" />
    <dataNode name="dn2" dataHost="localhost1" database="db2" />
    <dataNode name="dn3" dataHost="localhost1" database="db3" />
    <dataHost name="localhost1" maxCon="1000" minCon="10" balance="1" writeType="0" dbType="mysql" dbDriver="native" switchType="1" slaveThreshold="100">
        <heartbeat>select user()</heartbeat>
        <writeHost host="hostM1" url="59.69.165.38:3306" user="root" password="123456">
        	<readHost host="hostS2" url="59.69.165.50:3306" user="root" password="123456" />
        </writeHost>
        <writeHost host="hostM1" url="59.69.165.39:3306" user="root" password="123456">
        	<readHost host="hostS2" url="59.69.165.51:3306" user="root" password="123456" />
        </writeHost>
    </dataHost>
</mycat:schema>
```

### 第二种配置方案：

```xml
<?xml version="1.0"?>
<!DOCTYPE mycat:schema SYSTEM "schema.dtd">
<mycat:schema xmlns:mycat="http://io.mycat/">
    <schema name="TESTDB1" checkSQLschema="false" sqlMaxLimit="100">
    	<table name="tb_user" dataNode="dn1,dn2,dn3" rule="crc32slot" />
    	<table name="tb_admin" dataNode="dn4,dn5,dn6" rule="crc32slot1" />
    </schema>
    <dataNode name="dn1" dataHost="localhost1" database="db1" />
    <dataNode name="dn2" dataHost="localhost1" database="db2" />
    <dataNode name="dn3" dataHost="localhost1" database="db3" />
    <dataNode name="dn4" dataHost="localhost2" database="db1" />
    <dataNode name="dn5" dataHost="localhost2" database="db2" />
    <dataNode name="dn6" dataHost="localhost2" database="db3" />
    <dataHost name="localhost1" maxCon="1000" minCon="10" balance="1" writeType="0" dbType="mysql" dbDriver="native" switchType="2" slaveThreshold="100">
        <heartbeat>show slave status</heartbeat>
        <writeHost host="hostM1" url="59.69.165.38:3306" user="root" password="123456">
        </writeHost>
        <writeHost host="hostS1" url="59.69.165.50:3306" user="root" password="123456" />
    </dataHost>
    <dataHost name="localhost2" maxCon="1000" minCon="10" balance="1" writeType="0" dbType="mysql" dbDriver="native" switchType="2" slaveThreshold="100">
        <heartbeat>show slave status</heartbeat>
        <writeHost host="hostM2" url="59.69.165.39:3306" user="root" password="123456">
        </writeHost>
        <writeHost host="hostS2" url="59.69.165.51:3306" user="root" password="123456"/>
    </dataHost>
</mycat:schema>
```

### 1.balance 属性

* balance=”0”, 不开启读写分离机制，所有读操作都发送到当前可用的 writeHost 上。
* balance=”1”，全部的 readHost 与 stand by writeHost 参与 select 语句的负载均衡。
* balance=”2”，所有读操作都随机的在 writeHost、 readhost 上分发。
* balance=”3”，所有读请求随机的分发到 writeHost 对应的 readhost 执行，writerHost 不负担读压力。

### 2.writeType 属性

* writeType=”0”, 所有写操作发送到配置的第一个 writeHost，第一个挂了切到还生存的第二个 writeHost，重新启动后已切换后的为准，切换记录在配置文件中:conf/dnindex.properties（datanode index）。
* writeType=”1”，所有写操作都随机的发送到配置的 writeHost，1.5 以 后 废 弃 不 推 荐。

### 3.switchType 属性

也涉及到读写分离问题，可以解决 IO 延迟问题。

* switchType='-1' 表示不自动切换
* switchType='1' 默认值，表示自动切换
* switchType='2' 基于 MySQL 主从同步的状态决定是否切换读写主机,心跳语句为 show
* slave status。当心跳监测获取的数据发现了 IO 的延迟，则读操作自动定位到 writeHost
  中。如果心跳监测获取的数据没有 IO 延迟，则读操作自动定位到 readHost 中。建议为
  不同的表格定位不同的 dataHost 节点。

注 意： 在 mycat 中 ， rule.xml 配 置 文 件 中 定 义 的 分 片 规 则 只 能 给 一 个 表 格 使 用 。如果有多个表格使用同一个分片规则 ，需要再 rule.xml 配置文件中，为每个表格定义一个分片规则。 如：

```
<tableRule name="crc32slot">
    <rule>
    	<columns>id</columns>
    	<algorithm>crc32slot</algorithm>
    </rule>
    </tableRule>
<tableRule name="crc32slot1">
    <rule>
    	<columns>id</columns>
    	<algorithm>crc32slot</algorithm>
    </rule>
</tableRule>
```

