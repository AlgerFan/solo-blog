title: （14）MyCat  简介及相关术语——MySQL学习笔记
date: '2019-10-20 10:23:24'
updated: '2019-10-29 20:54:35'
tags: [MySQL]
permalink: /articles/2019/10/20/1571538203995.html
---
![](https://img.hacpai.com/bing/20180801.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 一、MyCat 简介

Mycat 是中间件，Java 编写的数据库中间件，Mycat 运行环境需要 JDK。运行在代码应用和 MySQL 数据库之间的应用。
前身 : corba。是阿里开发的数据库中间件，实现 MySQL 数据库分库分表集群管理的中间件，曾经出现过重大事故，二次开发，形成 Mycat。
使用 MyCat 之后，编写的所有的 SQL 语句，必须严格遵守 SQL 标准规范。
`insert into table_name(column_name) values(column_value);`
使用 MyCat 中间件后的结构图如下：

![mycat 简介 1.png](https://img.algerfan.cn/blog/image/20191020/d963daa6b9df40fc8b23c608833d118e.png)

## 二、MyCat 术语简介

### 1.切分

逻辑上的切分. 在物理层面,是使用多库[database],多表[table]实现的切分.

* 纵向切分
  把一个数据库切分成多个数据库，配置方便。只能实现两张表的表连接查询。
  将一张表中的数据，分散到若干个 database 的同结构表中。多个表的数据的集合是当前表格的数据。

  ![mycat 简介 2.png](https://img.algerfan.cn/blog/image/20191020/165a50e15c714424b44b56b7b83b5f6a.png)
* 横向切分

  把一个表切分成多个表，相比纵向切分配置麻烦。无法实现表连接查询。
  将一张表的字段，分散到若干张表中，将若干表连接到一起，才是当前表的完整数据。

  ![mycat 简介 5.png](https://img.algerfan.cn/blog/image/20191020/06e3e5d6ada54ff096712ed96b75b727.png)

### 2.逻辑库

Mycat 中定义的 database.是逻辑上存在的。但是物理上未必存在，主要是针对纵向切分提供的概念。访问 MyCat，就是将 MyCat 当做 MySQL 使用。
Db 数据库是 MyCat 中定义的 database。通过 SQL 访问 MyCat 中的 db 库的时候，对应的是 MySQL 中的 db1，db2，db3 三个库。物理上的 database 是 db1，db2，db3.逻辑上的 database 就是 db。

![mycat 简介 3.png](https://img.algerfan.cn/blog/image/20191020/bc68de5680f047bca5712826bfe3778c.png)

### 3.逻辑表

Mycat 中定义的 table，是逻辑上存在，物理上未必存在。主要是针对横向切分提供的概念。
MyCat 中的表格 table，其字段分散到 MySQL 数据库的表格 table1,table2,table3 中。

![mycat 简介 4.png](https://img.algerfan.cn/blog/image/20191020/6a1f441e15aa410d8f51ab812edefae1.png)

### 4.默认端口

Mycat 默认端口是 8066

### 5.数据主机 - dataHost

物理 MySQL 存放的主机地址，可以使用主机名、IP、域名定义。

### 6.数据节点 - dataNode

物理的 database 是什么。数据保存的物理节点，就是 database。

### 7.分片规则

当控制数据的时候，如何访问物理 database 和 table。就是访问 dataHost 和 dataNode 的算法。
在 Mycat 处理具体的数据 CRUD 的时候，如何访问 dataHost 和 dataNode 的算法。如:哈希算法、crc16 算法等。
