title: （13）MySQL 中的SQL 的15种优化策略——MySQL学习笔记
date: '2019-09-09 21:09:54'
updated: '2019-09-26 08:17:23'
tags: [MySQL]
permalink: /articles/2019/09/09/1568034594852.html
---
![](https://img.hacpai.com/bing/20180114.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## MySQL 中的SQL 的15种优化策略   
    
1. **避免全表扫描**  
    
对查询进行优化，应尽量避免全表扫描，首先应考虑在 where 及 order by 涉及的列上建立索引。   
    
2. **避免判断null 值**   
    
应尽量避免在 where 子句中对字段进行 null 值判断，否则将导致引擎放弃使用索引而进行全表扫描，如：   
    
`select id from t where num is null;`   
    
可以在 num 上设置默认值 0，确保表中 num 列没有 null 值，然后这样查询：   
    
`select id from t where num=0;`   
    
3. **避免不等值判断**   
    
应尽量避免在 where 子句中使用!=或<>操作符，否则引擎将放弃使用索引而进行全表扫描。   
    
4. **慎用in 和not in 逻辑**   
    
in 和 not in  也要慎用，否则会导致全表扫描，如： `select id from t1 where num in(select id from t2 where id> 10);` 此时外层查询会全表扫描，不使用索引。可以修改为：   
    
`select id from t1,(select id from t1 where id > 10)t2 where t1.id = t2.id;`   
    
此时索引被使用，可以明显提升查询效率。   
    
5. **注意模糊查询**   
    
下面的查询也将导致全表扫描：   
    
`select id from t where name like '%abc%';`   
    
模糊查询如果是必要条件时，可以使用 select id from t where name like 'abc%'来实现模糊查询，此时索引将被使用。如果头匹配是必要逻辑，建议使用全文搜索引擎（Elastic search、Lucene、Solr 等）。   
    
6. **避免查询条件中字段计算**   
    
应尽量避免在 where 子句中对字段进行表达式操作，这将导致引擎放弃使用索引而进行全表扫描。如：   
    
`select id from t where num/2=100;`   
    
应改为:   
    
`select id from t where num=100*2;`   
    
7. **避免查询条件中对字段进行函数操作**   
    
应尽量避免在 where 子句中对字段进行函数操作，这将导致引擎放弃使用索引而进行全表扫描。如：   
    
`select id from t where substring(name,1,3)='abc'--name;` 以 abc 开头的 id   
    
应改为:   
    
`select id from t where name like 'abc%';`   
    
8. **WHERE 子句“=”左边注意点**   
    
不要在 where  子句中的“=”左边进行函数、算术运算或其他表达式运算，否则系统将可能无法正确使用索引。   
    
9. **组合索引使用**   
    
在使用索引字段作为条件时，如果该索引是复合索引，那么必须使用到该索引中的第一个字段作为条件时才能保证系统使用该索引，否则该索引将不会被使用，并且应尽可能的让字段顺序与索引顺序相一致。   
    
10. **不要定义无异议的查询**   
    
不要写一些没有意义的查询，如需要生成一个空表结构：   
    
`select col1,col2 into #t from t where 1=0;`   
    
这类代码不会返回任何结果集，但是会消耗系统资源的，应改成这样：   
    
create table #t(...)   
    
11. **exists**   
    
很多时候用 exists 代替 in 是一个好的选择： `select num from a where num in(select num from b);` 用下面的语句替换：   
    
`select num from a where exists(select 1 from b where num=a.num);`   
    
12. **索引也可能失效**   
    
并不是所有索引对查询都有效，SQL 是根据表中数据来进行查询优化的，当索引列有大量数据重复时，SQL 查询可能不会去利用索引，如一表中有字段 sex，male、female 几乎各一半，那么即使在 sex 上建了索引也对查询效率起不了作用。   
    
13. **表格字段类型选择**   
    
尽量使用数字型字段，若只含数值信息的字段尽量不要设计为字符型，这会降低查询和连接的性能，并会增加存储开销。这是因为引擎在处理查询和连接时会逐个比较字符串中每一个字符，而对于数字型而言只需要比较一次就够了。   
    
尽可能的使用 varchar 代替 char ，因为首先可变长度字段存储空间小，可以节省存储空间，其次对于查询来说，在一个相对较小的字段内搜索效率显然要高些。   
    
14. **查询语法中的字段**   
    
任何地方都不要使用 select * from t  ，用具体的字段列表代替“*”，不要返回用不到的 任何字段。   
    
15. **索引无关优化**   
    
不使用*、尽量不使用 union，union all 等关键字、尽量不使用 or 关键字、尽量使用等值判断。   
    
表连接建议不超过 5 个。如果超过 5 个，则考虑表格的设计。（互联网应用中） 表连接方式使用外联优于内联。   
    
外连接有基础数据存在。如：A left join B,基础数据是 A。   
    
A inner join B，没有基础数据的，先使用笛卡尔积完成全连接，在根据连接条件得到内连接结果集。   
    
大数据量级的表格做分页查询时，如果页码数量过大，则使用子查询配合完成分页逻辑。   
    
`Select * from table limit 1000000, 10;`   
    
`Select * from table where id in (select pk from table limit 100000, 10);`

