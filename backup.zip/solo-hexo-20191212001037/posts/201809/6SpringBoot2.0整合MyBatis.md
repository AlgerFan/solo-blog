title: （6）Spring Boot2.0 整合MyBatis
date: '2018-09-10 09:12:14'
updated: '2019-10-05 15:15:41'
tags: [JavaWeb, Springboot, mybatis]
permalink: /articles/2018/09/10/1536541934000.html
---
![](https://img.hacpai.com/bing/20180107.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**示例源码下载：[https://github.com/AlgerFan/springBootExample](https://github.com/AlgerFan/springBootExample) ，欢迎star。**

引入依赖
```xml
<dependency>
	<groupId>org.mybatis.spring.boot</groupId>
	<artifactId>mybatis-spring-boot-starter</artifactId>
    <version>1.3.1</version>
</dependency>
```

![mybatis.png](https://img.algerfan.cn/blog/image/20190914/1bbb40c62b754896b40808a065c493bd.png)

步骤：

​	1）配置数据源相关属性（见上一节Druid）

​	2）给数据库建表

​	3）创建JavaBean

### 注解版

```java
/**
 * 指定这是一个操作数据库的mapper
 */
@Mapper
public interface DepartmentMapper {

    @Select("select * from department where id=#{id}")
    public Department getDeptById(Integer id);

    @Delete("delete from department where id=#{id}")
    public int deleteDeptById(Integer id);

    @Options(useGeneratedKeys = true,keyProperty = "id")
    @Insert("insert into department(departmentName) values(#{departmentName})")
    public int insertDept(Department department);

    @Update("update department set departmentName=#{departmentName} where id=#{id}")
    public int updateDept(Department department);
}
```

问题：

自定义MyBatis的配置规则；给容器中添加一个ConfigurationCustomizer；

```java
@org.springframework.context.annotation.Configuration
public class MyBatisConfig {

    @Bean
    public ConfigurationCustomizer configurationCustomizer(){
        return new ConfigurationCustomizer(){
            @Override
            public void customize(Configuration configuration) {
                configuration.setMapUnderscoreToCamelCase(true);
            }
        };
    }
}
```



```java
/**
 * 使用MapperScan批量扫描所有的Mapper接口
 */
@MapperScan(value = "cn.algerfan.springboot.mapper")
@SpringBootApplication
public class SpringBoot06DataMybatisApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBoot06DataMybatisApplication.class, args);
	}
}
```

### 配置文件版

```yaml
mybatis:
  config-location: classpath:mybatis/mybatis-config.xml 指定全局配置文件的位置
  mapper-locations: classpath:mybatis/mapper/*.xml  指定sql映射文件的位置
```

### 三种动态sql

脚本sql
XML配置方式的动态SQL我就不讲了，有兴趣可以自己了解，下面是用`<script>`的方式把它照搬过来，用注解来实现。适用于xml配置转换到注解配置

```java
@Select("<script>select * from user <if test=\"id !=null \">where id = #{id} </if></script>")  
public List<User> findUserById(User user);  
```

很明显，在java中写xml可读性和维护性太差，尤其当SQL很长时，这样写是很痛苦的。
在方法中构建sql
dao接口中是不能写实现的，所以这里借用内部类来生成动态SQL。增改删也有对应的@InsertProvider、@UpdateProvider、@DeleteProvider

```java
@Mapper
public interface MybatisDao {
	//使用UserDaoProvider类的findUserById方法来生成sql
	@SelectProvider(type = UserDaoProvider.class, method = "findUserById")
	public List<User> findUserById(User user);
	
	class UserDaoProvider {
		public String findUserById(User user) {
			String sql = "SELECT * FROM user";
			if(user.getId()!=null){
				sql += " where id = #{id}";
			}
			return sql;
		}
	}
```

这比`<script>`更加清晰，适用于查询语句不是很长、条件不多的场景，SQL很直观。但是在写很长的SQL时，这样拼接SQL同样会很痛苦
结构化SQL

```java
public String findUserById(User user) {    
            return new SQL(){{    
                SELECT("id,name");    
                SELECT("other");    
                FROM("user");    
                if(user.getId()!=null){    
                    WHERE("id = #{id}");    
                }    
                if(user.getName()!=null){    
                    WHERE("name = #{name}");    
                }    
            //从这个toString可以看出，其内部使用高效的StringBuilder实现SQL拼接    
            }}.toString();    
        }  
```
  
这是把前面的内部类改造一下。
SELECT：表示要查询的字段，如果一行写不完，可以在第二行再写一个SELECT，这两个SELECT会智能的进行合并而不会重复。
FROM和WHERE：跟SELECT一样，可以写多个参数，也可以在多行重复使用，最终会智能合并而不会报错。

上面的例子只是最基本的用法：更多详细用法，可以参考mybatis中文网的专门介绍
http://www.mybatis.org/mybatis-3/zh/statement-builders.html

List传值错误
动态SQL中，有时要对批量数据进行处理，难免会使用list做为参数。

```java
@SelectProvider(type = UserDaoProvider.class, method = "find")
	public List<Map> find(List list);    
	
	class UserDaoProvider {
		public String find(List list) {
```

这是一个最简单的list传参，但是在运行时会报传参错误。这是mybatis内部机制造成的，其参数需要是key/value结构，当遇到这里不是key/value结构的list时，mybatis会自己把它转换成key/value结构，key就是他的名字"list",value就是他的值List，要正确传参需要使用key/value结构的map，如下：

```java
@SelectProvider(type = UserDaoProvider.class, method = "find")
	public List<Map> find(List list);    
	
	class UserDaoProvider {
		public String find(Map map) {
			List list = (List) map.get("list");
```

更多使用参照

http://www.mybatis.org/spring-boot-starter/mybatis-spring-boot-autoconfigure/
