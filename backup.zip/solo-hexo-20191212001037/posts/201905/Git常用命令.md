title: Git常用命令
date: '2019-05-15 14:05:14'
updated: '2019-10-15 20:58:27'
tags: [Git]
permalink: /articles/2019/05/15/1557900314012.html
---
![](https://img.hacpai.com/bing/20190911.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## Git常用命令

### 创建版本库

```bash
#把这个目录变成Git可以管理的仓库
git init
#把文件添加到仓库
git add readme.txt
#把文件提交到仓库
git commit -m "wrote a readme file"
```

### 时光穿梭机

#### 版本回退

```bash
#查看历史记录
git log
#查询版本号
git log --pretty=oneline
#回退到上个版本，上上一个版本就是HEAD^^
git reset --hard HEAD^
#回退到指定版本号的版本
git reset --hard 1094a
#查询你的每一次命令，并且可以看到版本号
git reflog
```

#### 撤销修改

```bash
#撤销修改
git checkout -- readme.txt
#撤销已经add到暂存区的文件，再使用checkout即可撤销修改
git reset HEAD readme.txt
```

#### 删除文件

```bash
#删除一个文件
git rm test.txt
```

### 远程仓库

#### 添加远程库

```bash
#已有的本地仓库与远程仓库关联
git remote add origin git@github.com:账户名/仓库名.git
#将本地库的所有内容推送到远程库
#由于远程库是空的，我们第一次推送master分支时，加上了-u参数，Git不但会把本地的master分支内容推送的远程新的master分支，还会把本地的master分支和远程的master分支关联起来，在以后的推送或者拉取时就可以简化命令。
git push -u origin master
#之后就可以直接通过以下命令推送
git push origin master
```

#### 克隆仓库

```bash
#克隆一个仓库
git clone 仓库地址
```

### 分支管理

#### 创建和合并分支

下面要完成的是创建一个新的分支，在新的分支下完成提交，然后再将新的分支合并到master分支。

```bash
#创建并切换一个dev分支
git checkout -b dev
#git checkout命令加上-b参数表示创建并切换，相当于以下两条命令：
git branch dev
git checkout dev
#查看当前分支
git branch
#之后完成提交，切换回master分支，然后把dev分支的工作成果合并到master分支上
git merge dev
#删除分支
git branch -d dev
```

#### 解决冲突

当两个分支都有提交内容时，合并就会冲突，修改冲突以后，再次提交

```bash
#通过以下命令看到分支的合并情况
git log --graph --pretty=oneline --abbrev-commit
#以下命令可以看到分支合并图
git log --graph
```

#### 分支管理策略

通常，合并分支时，如果可能，Git会用`Fast forward`模式，但这种模式下，删除分支后，会丢掉分支信息。

如果要强制禁用`Fast forward`模式，Git就会在merge时生成一个新的commit，这样，从分支历史上就可以看出分支信息。

```bash
#合并分支时，加上--no-ff参数就可以用普通模式合并，合并后的历史有分支，能看出来曾经做过合并，而fast forward合并就看不出来曾经做过合并。
git merge --no-ff -m "merge with no-ff" dev
```

#### Bug分支

当你接到一个修复一个代号101的bug的任务时，很自然地，你想创建一个分支`issue-101`来修复它，但是，当前正在`dev`上进行的工作还没有提交，可以把当前工作现场“储藏”起来，等以后恢复现场后继续工作。

```bash
#将当前分支隐藏
git stash
#找到dev的工作现场
git stash list
#有两个办法：一是用git stash apply恢复，但是恢复后，stash内容并不删除，你需要用git stash drop来删除
git stash apply
git stash drop
#另一种方式是用git stash pop，恢复的同时把stash内容也删了
git stash pop
#再用git stash list查看，就看不到任何stash内容了
#你可以多次stash，恢复的时候，先用git stash list查看，然后恢复指定的stash，用命令：
git stash apply stash@{0}
```

#### Feature分支

每添加一个新功能，最好新建一个feature分支，在上面开发，完成后，合并，最后，删除该feature分支。

创建分支，提交，返回主分支合并。当新功能不需要时，强制删除使用-D：

```bash
#强制删除分支feature-vulcan
git branch -D feature-vulcan
```

#### 多人协作

查看远程库的信息，会显示可以抓取和推送的`origin`的地址。如果没有推送权限，就看不到push的地址。

```bash
#查看远程库的信息
git remote
#显示更详细的信息
git remote -v
#推送分支
git push origin master
#要推送其他分支，比如dev
git push origin dev
```

并不是一定要把本地分支往远程推送，那么，哪些分支需要推送，哪些不需要呢？

- `master`分支是主分支，因此要时刻与远程同步；

- `dev`分支是开发分支，团队所有成员都需要在上面工作，所以也需要与远程同步；

- bug分支只用于在本地修复bug，就没必要推到远程了，除非老板要看看你每周到底修复了几个bug；

- feature分支是否推到远程，取决于你是否和你的小伙伴合作在上面开发。

当dev分支冲突时，先用`git pull`把最新的提交从`origin/dev`抓下来，然后，在本地合并，解决冲突，再推送：

```bash
git pull
#git pull失败原因是没有指定本地dev分支与远程origin/dev分支的链接，根据提示，设置dev和origin/dev的链接
git branch --set-upstream-to=origin/dev dev
git pull
#修改冲突后再次提交
```

多人协作的工作模式通常是这样：

1. 首先，可以试图用`git push origin <branch-name>`推送自己的修改；
2. 如果推送失败，则因为远程分支比你的本地更新，需要先用`git pull`试图合并；
3. 如果合并有冲突，则解决冲突，并在本地提交；
4. 没有冲突或者解决掉冲突后，再用`git push origin <branch-name>`推送就能成功！

如果`git pull`提示`no tracking information`，则说明本地分支和远程分支的链接关系没有创建，用命令`git branch --set-upstream-to <branch-name> origin/<branch-name>`。

##### 小结

- 查看远程库信息，使用`git remote -v`；

- 本地新建的分支如果不推送到远程，对其他人就是不可见的；

- 从本地推送分支，使用`git push origin branch-name`，如果推送失败，先用`git pull`抓取远程的新提交；

- 在本地创建和远程分支对应的分支，使用`git checkout -b branch-name origin/branch-name`，本地和远程分支的名称最好一致；

- 建立本地分支和远程分支的关联，使用`git branch --set-upstream branch-name origin/branch-name`；（`git branch --set-upstream-to=origin/branch-name branch-name`）

- 从远程抓取分支，使用`git pull`，如果有冲突，要先处理冲突。

```bash
#把分叉的提交历史“整理”成一条直线，看上去更直观。缺点是本地的分叉提交已经被修改过了。再使用git log --graph --pretty=oneline --abbrev-commit查看提交历史，会发现Git把我们本地的提交“挪动”了位置。
git rebase
```

### 标签管理

#### 创建标签

```bash
#给当前分支打一个新标签
git tag v1.0
#查看所有标签
git tag
#给某个提交加上标签
git tag v0.9 f52c633
#标签不按顺序，查看标签信息
git show v0.9
#创建带有说明的标签
git tag -a v0.1 -m "version 0.1 released" 1094adb
```

#### 操作标签

```bash
#如果标签打错了，也可以删除
git tag -d v0.1
#要推送某个标签到远程
git push origin v1.0
#一次性推送全部尚未推送到远程的本地标签
git push origin --tags
#标签已经推送到远程，要删除远程标签就麻烦一点，先从本地删除
git tag -d v0.9
#然后，从远程删除
git push origin :refs/tags/v0.9
```

### 其他

#### 参与一个开源项目

如何参与一个开源项目呢？比如人气极高的bootstrap项目，这是一个非常强大的CSS框架，你可以访问它的项目主页<https://github.com/twbs/bootstrap>，点“Fork”就在自己的账号下克隆了一个bootstrap仓库，然后，从自己的账号下clone。

如果你想修复bootstrap的一个bug，或者新增一个功能，立刻就可以开始干活，干完后，往自己的仓库推送。

如果你希望bootstrap的官方库能接受你的修改，你就可以在GitHub上发起一个pull request。当然，对方是否接受你的pull request就不一定了。

#### 本地关联多个远程库

```bash
#先删除已关联的名为origin的远程库
git remote rm origin
#然后，先关联GitHub的远程库
git remote add github git@github.com:michaelliao/learngit.git
#接着，再关联码云的远程库
git remote add gitee git@gitee.com:liaoxuefeng/learngit.git
#查看远程库信息
git remote -v
```

#### 自定义Git

```bash
#让Git显示颜色，会让命令输出看起来更醒目
git config --global color.ui true
```

##### 忽略特殊文件

不需要从头写`.gitignore`文件，GitHub已经为我们准备了各种配置文件，只需要组合一下就可以使用了。所有配置文件可以直接在线浏览：<https://github.com/github/gitignore>

```bash
#有些时候，你想添加一个文件到Git，但发现添加不了，原因是这个文件被.gitignore忽略了
git add App.class
#如果你确实想添加该文件，可以用-f强制添加到Git
git add -f App.class
#或者你发现，可能是.gitignore写得有问题，需要找出来到底哪个规则写错了，可以用git check-ignore命令检查
git check-ignore -v App.class
```

##### 配置别名

```bash
#只需要敲一行命令，告诉Git，以后st就表示status
git config --global alias.st status
#比如
git config --global alias.co checkout
git config --global alias.ci commit
git config --global alias.br branch
#还可以把几个单词用指定字母代替
git config --global alias.unstage 'reset HEAD'
#配置一个git last，让其显示最后一次提交信息，用git last就能显示最近一次的提交
git config --global alias.last 'log -1'
```

##### 搭建Git服务器

推荐用Ubuntu或Debian，这样，通过几条简单的`apt`命令就可以完成安装。

```bash
#第一步，安装git：
sudo apt-get install git

#第二步，创建一个git用户，用来运行git服务：
sudo adduser git

#第三步，创建证书登录：
#收集所有需要登录的用户的公钥，就是他们自己的id_rsa.pub文件，把所有公钥导入到/home/git/.ssh/authorized_keys文件里，一行一个。

#第四步，初始化Git仓库：
#先选定一个目录作为Git仓库，假定是/srv/sample.git，在/srv目录下输入命令：
sudo git init --bare sample.git
#Git就会创建一个裸仓库，裸仓库没有工作区，因为服务器上的Git仓库纯粹是为了共享，所以不让用户直接登录到服务器上去改工作区，并且服务器上的Git仓库通常都以.git结尾。然后，把owner改为git：
sudo chown -R git:git sample.git

#第五步，禁用shell登录：
#出于安全考虑，第二步创建的git用户不允许登录shell，这可以通过编辑/etc/passwd文件完成。找到类似下面的一行：
git:x:1001:1001:,,,:/home/git:/bin/bash
#改为：
git:x:1001:1001:,,,:/home/git:/usr/bin/git-shell
#这样，git用户可以正常通过ssh使用git，但无法登录shell，因为我们为git用户指定的git-shell每次一登录就自动退出。

#第六步，克隆远程仓库：
#现在，可以通过git clone命令克隆远程仓库了，在各自的电脑上运行：
git clone git@server:/srv/sample.git
```


