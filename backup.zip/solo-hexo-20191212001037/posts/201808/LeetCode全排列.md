title: LeetCode全排列
date: '2018-08-25 18:31:52'
updated: '2019-07-21 09:40:48'
tags: [LeetCode]
permalink: /articles/2018/08/25/1535193112012.html
---
![](https://img.hacpai.com/bing/20180928.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、题目

[LeetCode地址](https://leetcode-cn.com/problems/permutations/description/)

给定一个没有重复数字的序列，返回其所有可能的全排列。

示例:

　    输入: 

　     [1,2,3]

　    输出:

　    [ [1,2,3],
　     [1,3,2],
　     [2,1,3],
　     [2,3,1],
　     [3,1,2],
　     [3,2,1] ]

### 二、分析

　    该题采用了回溯，刚开始接触回溯，不太好理解，基本概念、基本思想、步骤等等，具体了解-->[推荐博客](https://www.cnblogs.com/steven_oyj/archive/2010/05/22/1741376.html)

### 三、Java代码

```java
public static List<List<Integer>> permute(int[] nums) {
    List<List<Integer>> listList = new ArrayList<>();
    //开始回溯
    backtracking(listList, nums, 0);
    return listList;
}
private static void backtracking(List<List<Integer>> listList, int[] nums, int j) {

    if (j == nums.length) {
        List<Integer> list = new ArrayList<>();
        for (int num : nums) list.add(num);
        listList.add(list);
    }
    for (int i = j; i < nums.length; i++) {
        //i、j互换（刚开始自己跟自己换）
        swap(nums, i, j);
        //往上回溯
        backtracking(listList, nums, j+1);
        //回溯完，i、j互换，一个循环结束，回到了最初的1,2,3
        swap(nums, i, j);
    }
}
private static void swap(int[] nums, int m, int n) {
    int temp = nums[m];
    nums[m] = nums[n];
    nums[n] = temp;
}
```

### 四、提交结果

![46](https://img.algerfan.cn/blog/image/20190619/8a60a4b10b464d63a73cbd9d92221f8a.png)