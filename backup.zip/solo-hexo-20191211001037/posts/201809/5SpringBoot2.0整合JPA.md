title: （5）Spring Boot2.0 整合 JPA
date: '2018-09-10 08:35:14'
updated: '2019-09-25 22:45:31'
tags: [JavaWeb, Springboot, jpa]
permalink: /articles/2018/09/10/1536539714000.html
---
![](https://img.hacpai.com/bing/20180130.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**示例源码下载：[https://github.com/AlgerFan/springBootExample](https://github.com/AlgerFan/springBootExample) ，欢迎star。**

### 一、SpringData简介

![data-jpa.png](https://img.algerfan.cn/blog/image/20190914/25248a109b164471960e312462c080cd.png)

### 二、整合SpringData JPA

JPA:ORM（Object Relational Mapping）；

1）编写一个实体类（bean）和数据表进行映射，并且配置好映射关系；

```java
/**
 * 使用JPA注解配置映射关系
 * 告诉JPA这是一个实体类（和数据表映射的类）
 * @Table 来指定和哪个数据表对应;如果省略默认表名就是user；
 */
@Entity
@Table(name = "tbl_user")
public class User {

    /**
     * 这是一个主键、自增主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    /**
     * 这是和数据表对应的一个列
     */
    @Column(name = "last_name",length = 50)
    private String lastName;
    /**
     * 省略默认列名就是属性名
     */
    @Column
    private String email;
```

2）编写一个Dao接口来操作实体类对应的数据表（Repository）

```java
/**
 * 继承JpaRepository来完成对数据库的操作
 */
public interface UserRepository extends JpaRepository<User,Integer> {
}
```

3）基本的配置JpaProperties

```yaml
spring:  
 jpa:
    hibernate:
#     更新或者创建数据表结构
      ddl-auto: update
#    控制台显示SQL
    show-sql: true
```
