title: 精选！必备的VSCode插件
date: '2019-11-02 14:21:12'
updated: '2019-11-18 16:00:34'
tags: [开发工具]
permalink: /articles/2019/11/02/1572675672644.html
---
# 精选！必备的VSCode插件

## 1、Chinese Language

简体中文汉化插件，和我一样英文不好的童鞋可以安装这个插件进行汉化。这个插件重载之后还没有汉化成功的话，把编辑器关闭重新打开就行了。

## 2、vscode-icons

让 vscode 资源树目录加上图标，有利于我们进行文件格式的判断。

## 3、HTML Boilerplate

通过使用 HTML 模版插件，你就摆脱了为 HTML 新文件重新编写头部和正文标签的苦恼。你只需在空文件中输入 HTML，并按 Tab 键，即可生成干净的文档结构。

## 4、HTML Snippets

很实用的 HTML 代码提示插件。

## 5、HTMLHint

HTML 代码检测

## 6、HTML CSS Support

HTML 标签上写 class 智能提示当前项目所支持的样式。

## 7、jQuery Code Snippets

jQuery 代码提示，用 jQuery 框架的必须装。

## 8、Path Intellisense

自动路径补全，方便我们进行图片、CSS、JavaScript 等文件的路径编写。

## 9、Atuo Rename Tag

修改 HTML 标签，自动帮你完成尾部闭合标签的同步修改。

## 10、CSS Peek

使用此插件，你可以追踪至样式表中 CSS 类和 ids 定义的地方。当你在 HTML 文件中右键单击选择器时，选择“ Go to Definition 和 Peek definition ”选项，它便会给你发送样式设置的 CSS 代码。

## 11、Bracket Pair Colorizer

给括号设置不同的颜色，有利于括号多的时候进行区分。

## 12、Open-In-Browser

由于 VSCode 没有提供直接在浏览器中打开文件的内置界面，所以此插件在快捷菜单中添加了在默认浏览器查看文件选项，以及在客户端（Firefox，Chrome，IE）中打开命令面板选项。

## 13、beautify

格式化代码插件，感觉编辑器自带的就够用了。

## 14、Prettier

Prettier 是目前 Web 开发中最受欢迎的代码格式化程序。安装了这个插件，它就能够自动应用 Prettier，并将整个 JS 和 CSS 文档快速格式化为统一的代码样式。如果你还想使用 ESLint，那么还有个 Prettier – Eslint 插件，你可不要错过咯！

## 15、Color Info

这个便捷的插件，将为你提供你在 CSS 中使用颜色的相关信息。你只需在颜色上悬停光标，就可以预览色块中色彩模型的（HEX、 RGB、HSL 和 CMYK）相关信息了。

## 16、SVG Viewer

此插件在 Visual Studio 代码中添加了许多实用的 SVG 程序，你无需离开编辑器，便可以打开 SVG 文件并查看它们。同时，它还包含了用于转换为 PNG 格式和生成数据 URI 模式的选项。

## 17、TODO Highlight

这个插件能够在你的代码中标记出所有的 TODO 注释，以便更容易追踪任何未完成的业务。在默认的情况下，它会查找 TODO 和 FIXME 关键字。当然，你也可以添加自定义表达式。

## 18、Minify

这是一款用于压缩合并 JavaScript 和 CSS 文件的应用程序。它提供了大量自定义的设置，以及自动压缩保存并导出为.min 文件的选项。它能够分别通过 uglify-js、clean-css 和 html-minifier，与 JavaScript、CSS 和 HTML 协同工作。

## 19、Change Case

虽然 VSCode 内置了开箱即用的文本转换选项，但其只能进行文本大小写的转换。而此插件则添加了用于修改文本的更多命名格式，包括驼峰命名、下划线分隔命名，snake_case 命名以及 CONST_CAS 命名等。

## 20、Regex Previewer

这是一个用于实时测试正则表达式的实用工具。它可以将正则表达式模式应用在任何打开的文件上，并高亮所有的匹配项。

## 21、Language and Framework Packs

VSCode 默认支持大量的主流编程语言，但如果你所使用的编程语言不包括在内，也可以通过下载扩展包来自动添加。同时，你还可以添加一些像 React Native 与 Vue 的相关 Web 开发插件包。

## 22、Icon Fonts

这是一个能够在项目中添加图标字体的插件。该插件支持超过 20 个热门的图标集

• Material Icons Theme

• Font Awesome

• Ionicons

• Glyphicons

## 23、Themes

当然，在众多的实用插件中，岂能少了漂亮的主题呢？你每天都会与你的 VSCode 编辑器进行“亲密的接触”，为何不把它打扮得更漂亮些呢？这里有一些帮助你更改侧边栏的配色方案，以及图标的相关主题，与大家分享：

• One Dark

• Material Icon

## 24、Document this

js 的注释模板 （注意：新版的 vscode 已经原生支持,在 function 上输入/ tab）

## 25、vscode-fileheader

顶部注释模板，可定义作者、时间等信息，并会自动更新最后修改时间

## 26、Bootstrap 3 Sinnpet

Bootstrap 3 代码提示插件，常用的话需要下载一个。

## 27、Quokka

Quokka 是一个调试工具插件，能够根据你正在编写的代码提供实时反馈。它易于配置，并能够预览变量的函数和计算值结果。另外，在使用 JSX 或 TypeScript 项目中，它能够开箱即用。

## 28、Faker

使用流行的 JavaScrip t 库 – Faker，能够帮你快速的插入用例数据。Faker 可以随机生成姓名、地址、图像、电话号码，或者经典的乱数假文段落，并且每个类别还包含了各种子类别，你可以根据自身的需求来使用这些数据。

## 29、Code Spell Checker

代码拼写检查

## 30、Image preview

图片预览

## 31、markdownlint

定义了 Markdown 文件的标准和一致性，不符合标准会提示相应信息。

## 32、Markdown All in One

好用的 Markdown 插件，提供了快捷键、目录、清单编辑、导出 PDF、GitHub 主题、Math、自动提示。

## 31、FreeMarker

## 32、language-stylus

## 30、小程序助手

## 31、wechat-snippet

这两个都是微信小程序的代码提示及自动补全插件，现在微信小程序这么火怎么可以不下载。

