title: Java基础练习题二（Java基础、面向对象的继承、抽象、接口等等）
date: '2018-11-14 01:24:31'
updated: '2019-09-01 09:02:02'
tags: [JavaSE]
permalink: /articles/2018/11/14/1542129871012.html
---
以下为java入门的一些练习题，给大一出的考核题、特在此总结一下，主要包含Java基础概念、语言基础（数据类型、变量、运算符等等）、流程控制（分支结构、循环结构）、数组与字符串。

#### 一、 选择题

##### 1. 以下说法不正确的是( B )

A.  Java 是 sun 公司开发的，目前属于甲骨文公司
B.  Java 是一门简单易学的面向过程语言
C.  J2SE 是 Java 平台标准版
D.  Java 之父是James Gosling

##### 2. Java语言具有许多特点,下列选项中反映了Java程序并行机制的特点( B )

A.安全性		B.多线程		C.跨平台		D.可移植

##### 3. 八种基本类型中包括下列哪些( A )

A.int        B.public     C.String     D.void

##### 4. 变量命名规范说法正确的是( B )

A.变量由字母、下划线、数字、$符号随意组成;
B.变量不能以数字作为开头;
C.A和a在java中是同一个变量;
D.不同类型的变量,可以起相同的名字;

##### 5. 运算符优先级别排序正确的是( A )

A.由高向低分别是:算术运算符、关系运算符、逻辑运算符、赋值运算符
B.由高向低分别是:关系运算符、算术运算符、赋值运算符、逻辑运算符
C.由高向低分别是:算术运算符、逻辑运算符、关系运算符、赋值运算符
D.由高向低分别是:关系运算符、赋值运算符、算术运算符、逻辑运算符

##### 6. 下列代码输出结果是( B )

```java
int i = 10;
while ( i > 0 ){
    i = i + 1;
    if ( i = =10 ){
        break;
    }
}
```

A.while循环执行10次
B.死循环
C.循环一次都不执行
D.循环执行一次

##### 7. score是一个整数数组,有五个元素,已经正确初始化并赋值,仔细阅读下面代码,程序运行结果是( B )

temp = score[0];
for (int index = 1;index < 5;index++) {
if (score[index] < temp) {
temp = score[index];
}
}

A.求最大数                            B.求最小数
C.找到数组最后一个元素                D.编译出错

##### 8. 在java中语句：37.2％10的运算结果为( A )

  A.7.2          B.7            C.3            D. 0.2

##### 9. 下面数组定义错误的是( C )

A. int[] arr ={23,45,65,78,89}; 
B. int[] arr=new int[10];
C. int[] arr=new int[4]{3,4,5,6};
D. int[][] arr=new int[10][];

##### 10. 已知i为整形变量，关于一元运算 ＋＋i和i++，下列说法正确的是( D )

A．++i运算将出错
B．在任何情况下运行程序结果都一样
C. 在任何情况下运行程序结果都不一样
D. 在任何情况下变量i的值都增1

#### 二、 简答题

##### 1. 环境变量path和classpath的作用是什么？如何设置这两个环境变量？

- Path：
安装完JDK(Java Development Kit，Java开发工具包)之后，可以在安装目录下找到两个子目录(bin目录和lib目录)。bin目录中包含着Java编译器等可执行文件。
	如果要运行执行java命令，必须得执行java命令对应的可执行文件的路径，通常有两种方式：
	在%JAVA_HOME%目录下执行。
	执行命令的时候，指明路径%JAVA_HOME%/bin/java
但是，这样不是特别方便，这就是为什么配置环境变量。如果将%JAVA_HOME%/bin/，添加到环境变量PATH中。再执行java命令时(无论在哪个目录下执行)，系统就会从左到右搜索(这里的顺序很重要，可以利用这个特性覆盖掉某个旧版本的jdk。)环境变量PATH中执行的目录，直到找到对应的可执行文件并执行(找到之后，后面的目录都会被忽略掉)。如果找不到，提示该命令不存在。这就是PATH环境变量的作用。

- Classpath:
指定Java类所在的目录。当运行java程序的时候，要指定相应的类名.如果缺少这个环境变量，这里将会报找不到或无法加载主类的错误

##### 2. 什么是平台无关性？Java语言是怎样实现平台无关性的？

- 平台无关性是指Java语言可在任何具有JVM的平台上进行运行。
- Java程序编写后，经java编译器编译成独立于机器平台的字节码。字节码文件在任何具有JVM 的平台上均可运行

##### 3.	什么是 JDK，什么是 JRE，什么是 JVM。以及他们的联系与区别？

- JDK: 顾名思义它是给开发者提供的开发工具箱,是给程序开发者用的。它除了包括完整的JRE（Java Runtime Environment），Java运行环境，还包含了其他供开发者使用的工具包。
- JRE: 普通用户而只需要安装 JRE（Java Runtime Environment）来运行 Java 程序。而程序开发者必须安装JDK来编译、调试程序。
- JVM： 当我们运行一个程序时，JVM 负责将字节码转换为特定机器代码，JVM 提供了内存管理/垃圾回收和安全机制等。这种独立于硬件和操作系统，正是 java 程序可以一次编写多处执行的原因。

- 区别与联系：
JDK 用于开发，JRE 用于运行java程序 ；
JDK 和 JRE 中都包含 JVM ；
JVM 是 java 编程语言的核心并且具有平台独立性。

#### 三．编程题

##### 1. 有一分数序列：2/1，3/2，5/3，8/5，13/8，21/13...求出这个数列的前20项之和。

```java
public class Test_1 {

    public static void main(String[] args){
        double n1 = 1;
        double n2 = 1;
        double fraction = n1/n2;
        double Sn = 0;

        for(int i=0;i<20;i++){

            double t1 = n1;
            double t2 = n2;

            n1 = t1+t2;

            n2 = t1;

            fraction = n1/n2;

            Sn += fraction;

        }
        System.out.print(Sn);
    }
}
```

##### 2. 编写一个应用程序，接受用户输入的一行字符串，判断该字符串是否是回文数？

第一种方法：

```java
public class Test_2_1 {

    public static void main(String[] args) {
        String s = "";
        int a = 0;
        System.out.println("请输入一个字符串");
        Scanner input = new Scanner(System.in);
        s = input.next();
        for(int i=0;i<s.length()/2;i++){
            if(s.charAt(i)!=s.charAt(s.length()-i-1)){
                a = 1;
            }
        }
        if(a==1){
            System.out.println("此字符串不是一个回文字符串");
        } else {
            System.out.println("此字符串是一个回文字符串");
        }
    }
}
```

第二种方法

```java
public class Test_2_2 {

    public static void main(String[] args) {
        String str = "";
        System.out.println("请输入一个字符串");
        Scanner input = new Scanner(System.in);
        str = input.next();
        StringBuffer sb = new StringBuffer(str);
        sb.reverse();// 将Str中的字符串倒置

        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == sb.charAt(i)) {
                count++;
            }
        }
        if (count == str.length()) {
            System.out.println("此字符串是一个回文字符串");
        } else {
            System.out.println("此字符串不是一个回文字符串");
        }
    }
}
```

第三种方法：

```java
public class Test_2_3 {
    public static void main(String[] args) {
        System.out.println("请输入一个字符串");
        Scanner input = new Scanner(System.in);
        String str = input.next();
        StringBuilder sb=new StringBuilder(str);
        sb.reverse();//将str倒置的方法
        String newStr=new String(sb);
        if(str.equals(newStr)){
            System.out.println("此字符串是一个回文字符串");
        }else{
            System.out.println("此字符串不是一个回文字符串");
        }
    }
}
```

##### 3. 有1、2、3、4、5五个数字，能组成多少个互不相同且无重复数字的三位数？都是多少？有1、2、3、4、5五个数字，能组成多少个互不相同且无重复数字的三位数？都是多少？

```java
public class Test_3 {

    public static void main(String[] args) {
        int sum = 0;
        for(int i =1;i<6;i++){
             for(int j =1;j<6;j++){
                 for(int k =1;k<6;k++){
                     if ((i != k) &&((i != j) && (j != k))){
                         sum++;
                         System.out.println("组成的三位数："+i+j+k);
                     }
                 }
             }
        }
        System.out.println("总个数："+sum);
    }
}
```

##### 4. 输入一个字符，是字母则输入"YES!"否则输出"NO!"

```java
public class Test_4 {

    public static void main(String[] args) {
        System.out.println("请输入一个字符");
        Scanner input = new Scanner(System.in);
        String str = input.next();
        char c = str.charAt(0);
        if ((c>=65 && c<=90) || (c>=97 && c<=122)) {
            System.out.println("YES");
        }else{
            System.out.println("NO");
        }
    }
}
```
