title: GitHub clone太慢？来加速你的GitHub clone
date: '2019-07-25 22:23:24'
updated: '2019-10-03 10:38:11'
tags: [GitHub]
permalink: /articles/2019/07/25/1564064604429.html
---
![](https://img.hacpai.com/bing/20190907.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> 原因：git clone 特别慢是因为github.global.ssl.fastly.Net域名被限制了。只要找到这个域名对应的ip地址，然后在hosts文件中加上ip–>域名的映射，刷新DNS缓存就可以了

### 1. 查询域名global-ssl.fastly.Net和 github.com 公网地址

[https://www.ipaddress.com/](https://www.ipaddress.com/) 可以用这个查。

或者[  Dns检测|Dns查询 - 站长工具    查找检测列表里的TTL值最小的IP](http://tool.chinaz.com/dns/?type=1&host=github.global.ssl.fastly.net&ip=)  

分别查找`github.global.ssl.fastly.net`和`github.com`这两个网址的ip地址

### 2. 将ip地址添加到hosts文件

Linux：`sudo gedit /etc/hosts`
Windows：`C:\Windows\System32\drivers\etc\hosts`

![GitHub clone慢.jpg](https://img.algerfan.cn/blog/image/20190725/ea0f979ae4d04e01893f0c22e3e3be23.jpg)

保存退出

### 3. 刷新DNS缓存

修改完hosts还不会立即生效，你需要刷新DNS缓存，告诉电脑我的hosts文件已经修改了。

Linux：`sudo /etc/init.d/networking restart`

windows下刷新DNS的方法：

打开CMD

输入`ipconfig /flushdns`

**重新clone就会发现速度飞起**

![GitHub clone.png](https://img.algerfan.cn/blog/image/20191003/d990cc97780741ddbe241479ad67d2db.png)

如果不行就把`github.global.ssl.fastly.net`的配置删掉，只留`github.com`
