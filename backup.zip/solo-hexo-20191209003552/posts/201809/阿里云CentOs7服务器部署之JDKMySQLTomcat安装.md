title: 阿里云CentOs7服务器部署之JDK+MySQL+Tomcat安装
date: '2018-09-27 23:51:32'
updated: '2019-09-01 08:55:28'
tags: [Linux]
permalink: /articles/2018/09/27/1538063492012.html
---
![](https://img.hacpai.com/bing/20190103.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### **一、安装jdk**

#### 1. 登录Linux，切换到root用户

```shell
su root #获取root用户权限，当前工作目录不变(需要root密码)
或
sudo -i #不需要root密码直接切换成root（需要当前用户密码）
```

#### 2. 在usr/local目录下建立java安装目录

```shell
mkdir -p /usr/local/java
```

#### 3.上传安装文件到linux

解压tar.gz
首先需要安装依赖：

```shell
tar -zxvf jdk-8u181-linux-x64.tar.gz -C /usr/local/java
```

#### 4.配置环境变量：

```shell
vim /etc/profile

#set java environment
JAVA_HOME=/usr/local/java/jdk1.7.0_71
CLASSPATH=.:$JAVA_HOME/lib.tools.jar
PATH=$JAVA_HOME/bin:$PATH
export JAVA_HOME CLASSPATH PATH

重新加载配置文件：【否则环境变量不会重新执行】
source /etc/profile
```

### **二、安装MySQL**

#### 1、安装MySQL

```shell
[root@iZwz91ym290hfg2f3bgkxsZ ~]# wget 'https://dev.mysql.com/get/mysql57-community-release-el7-11.noarch.rpm'
```

#### 2、将源里面的信息读取出来

```shell
[root@iZwz91ym290hfg2f3bgkxsZ ~]# rpm -Uvh mysql57-community-release-el7-11.noarch.rpm
```

#### 3、安装mysql

方法一：直接安装最新的服务器版本

```shell
[root@iZwz91ym290hfg2f3bgkxsZ ~]# yum -y install mysql-community-server
```

方法二：安装下载包

```shell
[root@iZwz91ym290hfg2f3bgkxsZ ~]# ls
mysql57-community-release-el7-11.noarch.rpm
```

#### 4、启动mysql

```shell
[root@iZwz91ym290hfg2f3bgkxsZ ~]# service mysqld start
```

#### 5、查看是否已经启动了（如下就是已经启动了）

```shell
[root@iZwz91ym290hfg2f3bgkxsZ ~]# systemctl status mysqld
● mysqld.service - MySQL Server
   Loaded: loaded (/usr/lib/systemd/system/mysqld.service; enabled; vendor preset: disabled)
   Active: active (running) since 一 2018-03-26 17:03:05 CST; 50s ago
     Docs: man:mysqld(8)
           http://dev.mysql.com/doc/refman/en/using-systemd.html
  Process: 10570 ExecStart=/usr/sbin/mysqld --daemonize --pid-file=/var/run/mysqld/mysqld.pid $MYSQLD_OPTS (code=exited, status=0/SUCCESS)
  Process: 10497 ExecStartPre=/usr/bin/mysqld_pre_systemd (code=exited, status=0/SUCCESS)
 Main PID: 10575 (mysqld)
   CGroup: /system.slice/mysqld.service
           └─10575 /usr/sbin/mysqld --daemonize --pid-file=/var/run/mysqld/my...

3月 26 17:02:57 iz2ze2llim71y07x3numlbz systemd[1]: Starting MySQL Server...
3月 26 17:03:05 iz2ze2llim71y07x3numlbz systemd[1]: Started MySQL Server.
```

#### 6、查看初始密码

```shell
[root@iZwz91ym290hfg2f3bgkxsZ ~]# grep "password" /var/log/mysqld.log
```

#### 7、修改密码

```shell
[root@iZwz91ym290hfg2f3bgkxsZ ~]# mysql -uroot -p 
Enter password: 
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 2
Server version: 5.7.21

Copyright (c) 2000, 2018, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> 
```

#### 8、修改密码设置规则

```shell
mysql> set global validate_password_policy=0;
Query OK, 0 rows affected (0.00 sec)
```

#### 9、设置密码

```shell
mysql> SET PASSWORD FOR 'root'@'localhost' = 'hello123456';
Query OK, 0 rows affected (0.00 sec)
```

#### 10、修改默认编码

查看字符集 `show variables like '%character%';`
修改文件`vim /etc/my.cnf`
添加

```shell

[mysqld]
character_set_server=utf8

[mysql]
default-character-set= utf8

[client]
default-character-set = utf8

```

重启`service mysql restart`

#### 11、访问权限

1）登录服务器的mysql，并打开mysql数据库  
`use mysql`
2）设置访问权限
第一种：将host设置为%表示任何ip都能连接mysql
`update user set host='%' where user='root' and host='localhost';`
第二种：当然也可以将host指定为某个ip
`update user set host='106.39.178.131' where user='root' and host='localhost';`
3）刷新权限表,使配置生效
`flush privileges;`

#### 12、检查服务器防火墙3306端口和阿里云的安全组规则中是否开放了3306端口，若没开放需要去开放

#### 13、接下来就可以远程连接了

### **三、安装Tomcat**

#### 1.下载tomcat

官方下载地址：[tomcat8官方下载地址](https://tomcat.apache.org/download-80.cgi) 

#### 2.安装tomcat

安装好jdk后，同时也下载好tomcat安装包，使用ftp功能将安装包放入指定的目录下

（1）创建目录

```shell
mkdir -p /usr/local/tomcat
```

（2）解压tomcat安装包

```shell
tar -zxvf apache-tomcat-8.0.53.tar.gz  -C /usr/local/tomcat
```

（3）删除tomcat安装包（如果需要）

```shell
rm -rf apache-tomcat-8.0.53.tar.gz
```

（4）修改文件名（解压后的文件名过长，可以考虑修改短）

```shell
mv  apache-tomcat-8.0.53 tomcat8
```

（5）进入tomcat的目录（根据自己的安装目录来）

```shell
cd /usr/local/tomcat/tomcat8/bin
```

（6）查看tomcat的运行状态

```shell
ps -ef |grep tomcat
```

（7）启动tomcat

```shell
./startup.sh
```

（8）关闭tomcat

```shell
./shutdown.sh
```

（9）访问服务器ip地址
![FMgFIKm.png](https://img.algerfan.cn/blog/image/20190406/e430a9e40584434281893c36bb9463cf.png)
