title: （15）MySQL  主从备份——MySQL学习笔记
date: '2019-10-20 10:29:20'
updated: '2019-10-29 20:54:16'
tags: [MySQL]
permalink: /articles/2019/10/20/1571538560569.html
---
![](https://img.hacpai.com/bing/20181008.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 一、主从备份概念

什么是主从备份: 就是一种主备模式的数据库应用。
主库(Master)数据与备库(Slave)数据完全一致。
实现数据的多重备份, 保证数据的安全。
可以在 Master[InnoDB]和 Slave[MyISAM]中使用不同的数据库引擎,实现读写的分离。

### 1、MySQL5.5  版本后本身支持主从备份

在老旧版本的 MySQL 数据库系统中,不支持主从备份,需要安装额外的 RPM 包。
如果需要安装 RPM,只能在一个位置节点安装。

### 2、主从备份目的

#### 实现主备模式

保证数据的安全，尽量避免数据丢失的可能。

#### 实现读写分离

使用不同的数据库引擎，实现读写分离，提高所有的操作效率。
InnoDB 使用 DML 语法操作，MyISAM 使用 DQL 语法操作。

### 3、主从备份效果

#### 主库操作同步到备库

所有对 Master 的操作，都会同步到 Slave 中。
如果 Master 和 Salve 天生上环境不同,那么对 Master 的操作，可能会在 Slave 中出现错误，如: 在创建主从模式之前，Master 有 database : db1、db2、db3，Slave 有 database: db1、db2。创建主从模式.现在的情况 Master 和 Slave 天生不同。
主从模式创建成功后，在 Master 中 drop database db3。Slave 中抛出数据库 SQL 异常，后续所有的命令不能同步。一旦出现错误，只能重新实现主从模式。

## 二、主 从 备 份 配 置

主要操作 Master 和 Slave 中的配置文件和 DBMS 的配置。
配置文件: 定义主从模式的基础信息。如: 日志, 命令等。
DBMS 配置: 提供主从访问的用户,基础信息 Master 和 Slave 的位置、用户名、密码、日志文件名等等。
建议：建立主从备份的多个 MySQL，最好原始环境一致。Database、table、data 完全一致。

### 1、Master[主库]配置

#### 修改 Master 配置文件

/etc/my.cnf
需要修改，修改前建议复制一份备份文件。
修改后的 my.cnf 配置文件,参考资料中的 my.cnf 文件内容。

**server-id**

本环境中 server-id 是 1
MySQL 服务唯一标识
唯一标识是数字.自然数
配置的时候有要求

* 单机使用
  server-id 任意配置,只要是数字即可。
* 主从使用
  server-id Master 唯一标识数字必须小于 Slave 唯一标识数字。

**log_bin**

本环境中 log_bin 值 : master_log
日志文件命名, 开启日志功能。此日志记录了主库中执行的所有的 SQL 命令的。

* 开启日志
  MySQL 的 log_bin 不是执行日志，状态日志。是操作日志.就是在 DBMS 中所有的 SQL 命令
  log_bin 日志不是必要的.只有配置主从备份时才必要。
* 日志文件配置
  变量的值就是日志文件名称，是日志文件名称的主体。
  MySQL 数据库自动增加文件名后缀和文件类型。

#### 重启 MySQL

`service mysqld restart`

#### 配置 Master

**访问 MySQL**
`mysql -uusername -ppassword`

* 创建用户
  在 MySQL 数据库中，为不存在的用户授权，就是同步创建用户并授权，此用户是从库访问主库使用的用户
  ip 地址不能写为%。因为主从备份中,当前创建的用户，是给从库 Slave 访问主库 Master 使用的，用户必须有指定的访问地址，不能是通用地址。
  `grant all privileges on *.* to ‘username’@’ip’ identified by ‘password’ with grant option;`
  `flush privileges;`

  例如：

  `grant all privileges on *.* to 'slave'@'192.168.199.133' identified by 'slave' with grant option;`
  `flush privileges;`
* 查看用户
  `use mysql;`
  `select host,userfrom user;`
* 查看 Master 信息
  `show master status;`

### 2、Slave[从库]配置

#### 修改 Slave 配置文件

/etc/my.cnf

**server_id**

唯一标识，本环境中配置为 : 2

**log_bin**

可以使用默认配置，也可以注释。

#### 可选: 修改 uuid

主从模式要求多个 MySQL 物理名称不能相同。即按装 MySQL 过程中 Linux 自动生成的物理标志。唯一物理标志命名为 uuid。保存位置是 MySQL 数据库的数据存放位置。默认为/var/lib/mysql 目录中。文件名是 auto.cnf。
修改 auto.cnf 文件中的 uuid 数据. 随意修改,不建议改变数据长度.建议改变数据内容。

#### 重启 MySQL  服 务

service mysqld restart

#### 配置 Slave

* 访问 MySQL
  `mysql -uusername -ppassword`
  1.3.2.4.2 停止 止 Slave  功 能
  `stop slave;`
* 配置主库信息
  需要修改的数据是依据 Master 信息修改的。ip 是 Master 所在物理机 IP， 用户名和密码是 Master 提供的 Slave 访问用户名和密码。日志文件是在 Master 中查看的主库信息提供的，在 Master 中使用命令 show master status 查看日志文件名称。
  `change master to master_host=’ip’, master_user=’username’, master_password=’password’, master_log_file=’log_file_name’;`

  例如：

  `change master to master_host='192.168.199.212', master_user='slave', master_password='slave', master_log_file='master_log.000001';`
* 启动 Slave 功能
  `start slave;`
* 查看 Slave 配置
  `show slave status \G;`

```
  mysql> show slave status \G;
  *************************** 1. row ***************************
                 Slave_IO_State: Waiting for master to send event
                    Master_Host: 10.1.36.67
                    Master_User: slave
                    Master_Port: 3306
                  Connect_Retry: 60
                Master_Log_File: master_log.000001
            Read_Master_Log_Pos: 1277
                 Relay_Log_File: localhost-relay-bin.000002
                  Relay_Log_Pos: 1492
          Relay_Master_Log_File: master_log.000001
               Slave_IO_Running: Yes
              Slave_SQL_Running: Yes
                Replicate_Do_DB: 
            Replicate_Ignore_DB: 
             Replicate_Do_Table: 
         Replicate_Ignore_Table: 
        Replicate_Wild_Do_Table: 
    Replicate_Wild_Ignore_Table: 
                     Last_Errno: 0
                     Last_Error: 
                   Skip_Counter: 0
            Exec_Master_Log_Pos: 1277
                Relay_Log_Space: 1703
                Until_Condition: None
                 Until_Log_File: 
                  Until_Log_Pos: 0
             Master_SSL_Allowed: No
             Master_SSL_CA_File: 
             Master_SSL_CA_Path: 
                Master_SSL_Cert: 
              Master_SSL_Cipher: 
                 Master_SSL_Key: 
          Seconds_Behind_Master: 0
  Master_SSL_Verify_Server_Cert: No
                  Last_IO_Errno: 0
                  Last_IO_Error: 
                 Last_SQL_Errno: 0
                 Last_SQL_Error: 
    Replicate_Ignore_Server_Ids: 
               Master_Server_Id: 1
                    Master_UUID: 24fbce5b-266b-11e7-b0a7-5254008815b6
               Master_Info_File: /var/lib/mysql/master.info
                      SQL_Delay: 0
            SQL_Remaining_Delay: NULL
        Slave_SQL_Running_State: Slave has read all relay log; waiting for more updates
             Master_Retry_Count: 86400
                    Master_Bind: 
        Last_IO_Error_Timestamp: 
       Last_SQL_Error_Timestamp: 
                 Master_SSL_Crl: 
             Master_SSL_Crlpath: 
             Retrieved_Gtid_Set: 
              Executed_Gtid_Set: 
                  Auto_Position: 0
           Replicate_Rewrite_DB: 
                   Channel_Name: 
             Master_TLS_Version: 
  1 row in set (0.00 sec)

  ERROR: 
  No query specified
```

#### 测试主从

### 3、主从模式下的逻辑图

![主从复制 1.png](https://img.algerfan.cn/blog/image/20191018/05547b1657ae4de0b44dceea09804a32.png)

