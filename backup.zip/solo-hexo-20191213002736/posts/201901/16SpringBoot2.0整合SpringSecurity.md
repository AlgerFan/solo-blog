title: （16）Spring Boot2.0 整合Spring Security
date: '2019-01-18 17:01:14'
updated: '2019-10-18 16:30:54'
tags: [JavaWeb, Springboot, 权限]
permalink: /articles/2019/01/18/1547802074012.html
---
![](https://img.hacpai.com/bing/20190606.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**示例源码下载：[https://github.com/AlgerFan/springBootExample](https://github.com/AlgerFan/springBootExample) ，欢迎star。**

## 一、Spring Security介绍

Spring Security是针对Spring项目的安全框架，也是Spring Boot底层安全模块默认的技术选型。他可以实现强大的web安全控制。对于安全控制，我们仅需引入spring-boot-starter-security模块，进行少量的配置，即可实现强大的安全管理。  
  
几个类：  
  
WebSecurityConfigurerAdapter：自定义Security策略  
  
AuthenticationManagerBuilder：自定义认证策略  
  
@EnableWebSecurity：开启WebSecurity模式  
  
* 应用程序的两个主要区域是“认证”和“授权”（或者访问控制）。这两个主要区域是Spring Security 的两个目标。  
  
* “认证”（Authentication），是建立一个他声明的主体的过程（一个“主体”一般是指用户，设备或一些可以在你的应用程序中执行动作的其他系统）。  
  
* “授权”（Authorization）指确定一个主体是否允许在你的应用程序执行一个动作的过程。为了抵达需要授权的店，主体的身份已经有认证过程建立。  
  
* 这个概念是通用的而不只在Spring Security中。

Spring Security主要组件图
![Spring Security-主要组件图.jpg](https://img.algerfan.cn/blog/image/20190725/9255e4fd6d1c4810b76558650fd64ad1.jpg)
Spring Security-核心处理流程图
![Spring Security-核心处理流程图.jpg](https://img.algerfan.cn/blog/image/20190725/f5a48d250895446691bc9ae3f2e36dfd.jpg)

### Spring Security常用权限拦截器 

- SecurityContextPresistenceFilter
- LogoutFilter
- AbstractAuthenticationProcessingFiter
- DefaultLoginPageGeneratingFilter
- BasicAuthenticationFilter
- SecurityContextHolderAwareRequestFilter
- RememberMeAuthenticationFilter
- AnonymousAuthenticationFilter
- ExceptionTranslationFilter
- SessionManagementFilter
- FilterSecurityInterceptor
- FilterChainProxy


## 二、Spring Security整合

### 1、引入SpringSecurity

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-security</artifactId>
</dependency>
```

### 2、编写SpringSecurity的配置类

```java
@EnableWebSecurity
public class MySecurityConfig extends WebSecurityConfigurerAdapter {
}
```

### 3、定制请求的授权规则

```java
	@Override
	protected void configure(HttpSecurity http) throws Exception {
	    //定制请求的授权规则
	    http.authorizeRequests().antMatchers("/").permitAll()
 	           .antMatchers("/product/**").hasRole("商品管理员")
	            .antMatchers("/order/**").hasRole("订单管理员")
	            .antMatchers("/admin/**").hasRole("超级管理员");
	    //...
	}
```

### 4、定义认证规则：

```java
	@Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication()
                .withUser("zhangsan").password("123456").roles("商品管理员","订单管理员")
                .and()
                .withUser("lisi").password("123456").roles("订单管理员","超级管理员")
                .and()
                .withUser("wangwu").password("123456").roles("商品管理员","超级管理员");
    }
```

### 5、登陆/注销

HttpSecurity配置登陆、注销功能

```java
/*
开启自动配置的登陆功能，效果，如果没有登陆，没有权限就会来到登陆页面
使用默认的登录页面
1、/login来到登陆页
2、重定向到/login?error表示登陆失败
 */
//http.formLogin();
/*
使用自己的登录页面
1、默认post形式的 /login代表处理登陆
2、一但定制loginPage；那么 loginPage的post请求就是登陆
 */
http.formLogin().usernameParameter("user").passwordParameter("pwd")
        .loginPage("/userLogin");

/*
开启自动配置的注销功能，注销成功以后来到首页
1、访问 /logout 表示用户注销，清空session
2、注销成功会返回 /login?logout 页面；
 */
http.logout().logoutSuccessUrl("/");
```

### 6、Thymeleaf提供的SpringSecurity标签支持

需要引入thymeleaf-extras-springsecurity4

```xml
<dependency>
    <groupId>org.thymeleaf.extras</groupId>
    <artifactId>thymeleaf-extras-springsecurity4</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-thymeleaf</artifactId>
</dependency>
```

相关标签使用

* `sec:authorize="isAuthenticated()"`判断是否有权限
* `sec:authentication="name"`获得当前用户的用户名
* `sec:authentication="principal.authorities"`获得用户的权限
* `sec:authorize="hasRole('超级管理员')"`当前用户必须拥有超级管理员权限时才会显示标签内容

```html
<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org"
	  xmlns:sec="http://www.thymeleaf.org/thymeleaf-extras-springsecurity4">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Insert title here</title>
</head>
<body>
<h1 align="center">欢迎光临商城管理系统</h1>
<div sec:authorize="!isAuthenticated()">
	<h2 align="center">游客您好，如果想进入管理系统 <a th:href="@{/userLogin}">请登录</a></h2>
</div>
<div sec:authorize="isAuthenticated()">
	<h2>
		<span sec:authentication="name"></span>，您好,您的角色有：
		<span sec:authentication="principal.authorities"></span>
	</h2>
	<form th:action="@{/logout}" method="post">
		<input type="submit" value="注销"/>
	</form>
</div>
<hr>

<div sec:authorize="hasRole('商品管理员')">
	<h3>商品管理</h3>
	<ul>
		<li><a th:href="@{/product/1}">商品管理1</a></li>
		<li><a th:href="@{/product/2}">商品管理2</a></li>
	</ul>
</div>

<div sec:authorize="hasRole('订单管理员')">
	<h3>订单管理</h3>
	<ul>
		<li><a th:href="@{/order/1}">订单管理1</a></li>
		<li><a th:href="@{/order/2}">订单管理2</a></li>
	</ul>
</div>

<div sec:authorize="hasRole('超级管理员')">
	<h3>超级管理员</h3>
	<ul>
		<li><a th:href="@{/admin/1}">商品管理</a></li>
		<li><a th:href="@{/admin/2}">订单管理</a></li>
		<li><a th:href="@{/admin/3}">用户管理</a></li>
	</ul>
</div>

</body>
</html>
```

```html
<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org">
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	<h1 align="center">欢迎登陆商城管理系统</h1>
	<hr>
	<div align="center">
		<form th:action="@{/userLogin}" method="post">
			用户名:<input name="user"/><br>
			密码:<input name="pwd"><br/>
			<input type="submit" value="登陆">
		</form>
	</div>
</body>
</html>
```

### 7、登录记住我

* 表单添加remember-me的checkbox

  ```html
  <input type="checkbox" name="remeber"> 记住我<br/>
  ```

* 配置启用remember-me功能

  ```java
  		/*
          开启记住我功能，默认为remember-me
          登陆成功以后，将cookie发给浏览器保存，以后访问页面带上这个cookie，只要通过检查就可以免登录
          点击注销会删除cookie
           */
          http.rememberMe().rememberMeParameter("remeber");
  ```

### 8、如果启动报错There is no PasswordEncoder mapped for the id "null"

spring security 5 对 PasswordEncoder 做了相关的重构，原先默认配置的 PlainTextPasswordEncoder（明文密码）被移除了，想要做到明文存储密码，只能使用一个过期的类来过渡

```java
	/**
     * 已过期，开发时过渡使用
     */
    @Bean
    PasswordEncoder passwordEncoder(){
        return NoOpPasswordEncoder.getInstance();
    }
```






