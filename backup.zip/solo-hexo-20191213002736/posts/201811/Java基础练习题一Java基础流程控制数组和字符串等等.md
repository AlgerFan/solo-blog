title: Java基础练习题一（Java基础、流程控制、数组和字符串等等）
date: '2018-11-02 01:12:52'
updated: '2019-09-01 09:02:11'
tags: [JavaSE]
permalink: /articles/2018/11/02/1541092372012.html
---
以下为java入门的一些练习题，给大一出的考核题、特在此总结一下，主要包含Java基础概念、语言基础（数据类型、变量、运算符等等）、流程控制（分支结构、循环结构）、数组与字符串、类与对象、Java语言特性（成员、方法等等）、继承、抽象、接口、正则表达式。

#### 一、 选择题

##### 1. 下列 javaDoc 注释正确的是（C）

A、 /* 我爱北京天安门 */
B、 //我爱北京天安门 */
C、 /** 我爱北京天安门 */
D、 /* 我爱北京天安门 **/

##### 2. 在 Java语言中，下列关于类的继承的描述，正确的是（B）

A、 一个类可以继承多个父类
B、 一个类可以具有多个子类
C、 子类可以使用父类的所有方法
D、 子类一定比父类有更多的成员方法

##### 3. 下面说法中错误的是( D )

A、 静态代码块类一加载只执行一次 , 以后再创建对象的时候不执行
B、 局部代码块的作用是为了限制变量的生命周期
C、 构造代码块在每创建一次对象就执行一次
D、 以上都不对

##### 4. 下列关于修饰符混用的说法，错误的是（BD）

A、 abstract不能与final并列修饰同一个类
B、 abstract类中不可以有private的成员
C、 abstract方法必须在abstract类中
D、 static方法中能处理非static的属性

##### 5. 我国最高山峰是珠穆朗玛峰，8848米。现在我有一张足够大的纸，它的厚度是0.001米。请问，我折叠多少次，可以折成珠穆朗玛峰的高度（C）

A、 20
B、 22
C、 24
D、 26

##### 6. 分析选项中关于Java中this关键字的说法正确的是（A）

A、 this关键字是在对象内部指代自身的引用
B、 this关键字可以在类中的任何位置使用
C、 this关键字和类关联,而不是和特定的对象关联
D、 同一个类的不同对象共用一个this

##### 7. 下列关于字符串的描叙中错误的是（C）

A、 字符串是对象
B、 String 对象存储字符串的效率比 StringBuffer 低
C、 可以使用 StringBuffer sb="这里是字符串"; ，声明并初始化 StringBuffer 对象 sb
D、 String 类提供了许多用来操作字符串的方法：连接，提取，查询等

##### 8. 下列选项中关于 Java中封装的说法错误的是（D）

A、 封装就是将属性私有化，提供共有的方法访问私有属性
B、 属性的访问方法包括 setter 方法和 getter 方法
C、 setter 方法用于赋值， getter 方法用于取值
D、 包含属性的类都必须封装属性，否则无法通过编译

##### 9. 在Java中,下面对于构造函数的描述错误的是（C）

A、 类不一定要显式定义构造函数
B、 构造函数的返回类型是void
C、 如果构造函数不带任何参数,那么构造函数的名称和类名可以不同
D、 一个类可以定义多个构造函数

##### 10. 匹配一个以155开头和1379结尾的11位电话号码，以下选项正则表达式正确的是（A）**

A、 ^（155）[0-9]{4}(1379)$
B、 ^ 155(.){4}(1379)$
C、 ^（155）{0-9}{4}(1379)$
D、 ^ 155[\\w]{4}(1379)$

#### 二、 简答/填空题

##### 1. abstract 与哪些关键字不能共存为什么？

答案：final：首先abstract修饰的类，该类中的方法子类继承之后需要重写的，可是final修饰的类不能比继承，也就没子类，方法更不能得到重写，相互冲突；不能共存
private：私有的意思，方法子类是不能被继承到的，那么方法就没有被重写，可是abstract是要求方法重写的也相互冲突；不能共存
static：static能被实例化可直接调用，abstract是不能被实例化的，冲突，不能共存。所谓实例化就是创建对象理解为new对象就可以了；
2. 给定 java 代码如下所示，在 A 处增加一个方法，是对 cal 方法的重载
	public class Test {
	​	public void cal(int x, int y, int z) {
	​		
	}
	​	//A
	​	
	}
答案：public int cal(int x,int y,float z){}
	  或 public void cal(int x,int z){}

##### 3. 美国数学家维纳(N.Wiener)智力早熟，11岁就上了大学。他曾在1935~1936年应邀来中国清华大学讲学。一次，他参加某个重要会议，年轻的脸孔引人注目。于是有人询问他的年龄，他回答说：“我年龄的立方是个4位数。我年龄的4次方是个6位数。这10个数字正好包含了从0到9这10个数字，每个都恰好出现1次。”请问他的年龄是______。

答案：18

##### 4. 用Calendar类来获取系统时间的年份________。

答案：Calendar calendar=Calendar.getInstance();int year = calendar.get(Calendar.YEAR);   

#### 三、 编程题

##### 1. 给一个不多于5位的正整数，要求：一、求它是几位数，二、逆序打印出各位数字

答案：
（解法一）

```java
public class test1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int[] a = new int[5];
		int temp = 0;
		for (int i = 0; i < a.length; i++) {
			a[i] = n % 10;
			System.out.print(a[i] + " ");
			n = n / 10;
			if (n == 0) {
				temp = i + 1;
				System.out.println();
				break;
			}
		}
		System.out.println("位数 "+temp);
	}
}
```

解法二：

```java
public class test1{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.println("输入一个5位或5位以下的数字");
		int num = scan.nextInt();
		String s = String.valueOf(num);
		System.out.println("输入数字的长度为："+s.length());
		for(int i=s.length()-1;i>=0;i--){
		System.out.print(s.charAt(i)+" ");
		}
	}
}
```

##### 2. 有一对兔子，从出生后第3个月起每个月都生一对兔子，小兔子长到第三个月后每个月又生一对兔子，假如兔子都不死，问前20个月每个月的兔子总数为多少？

答案：

```java
public class test2 {
    public static void main(String[] args) {
        System.out.println("斐波那契数列：" );
        //方法一：变量
        int a=1 , b=1 , c=0;
        System.out.print( a +" " + b + " ");
        for(int i=2; i<20; i++){
            c = a + b;
            a = b;
            b = c;
            System.out.print(c + " ");
        }
        System.out.println();
        //方法二：数组
        int[] a1 = new int[20];
        a1[0] = 1;
        a1[1] = 1;
        System.out.print( a1[0] +" " + a1[1]+" ");
        for(int i=2; i<a1.length; i++){
            a1[i] = a1[i-1] + a1[i-2];
            System.out.print(a1[i] + " ");
        }
        System.out.println();
        //方法三：递归
        for(int i=1; i<= 20; i++){
            System.out.print(fibonacci(i) + " ");
        }
    }
    public static int fibonacci(int n){

        if( n == 1 || n == 2){
            return 1;
        }

        return (fibonacci(n-1) + fibonacci(n-2));
    }
}
```

##### 3. 按题目编程实现下列功能。

要求：按照题目所给变量名称、类型和方法名称进行编程，禁止修改；

- （1） 图书馆接口（Library）

		成员方法：
	​		borrow( )，借阅图书
	​		revert( )，归还图书
- （2） 图书类（Book）

		成员变量：
	​		图书名称（name)			String类型 
	​		出版社(publisher) 			String类型
	​	构造方法：
	​		通过形参初始化图书名称（name）和出版社（publisher）
	​	普通方法：
	​		1）设置gettor和settor方法用于获取和设置类中name变量的值；
	​		2）重写Equals方法，当且仅当书名（name)和出版社(publisher) 均相等时，即为同一本书。
	​		3）重写toString方法，返回书名（name)和出版社(publisher)的信息，样式如下：“书名：Java程序设计，出版社：清华大学出版社”
- （3） 馆藏图书类（CollectionBook），继承自Book类，实现Library接口

		成员变量：
	​		图书编号（bId）			String类型 			
	​		是否借阅（isBorrow）	boolean类型		图书状态为已借阅时，值为true
	​	构造方法：
	​		调用父类构造方法初始化书名（name)和出版社(publisher)信息，然后初始化图书编号（bId）和线路图书书库（stacks）。
	​	普通方法：
	​		1）实现接口中的borrow方法
	​			如果图书状态为已借阅，则输出“对不起，该图书已借阅”，否则，修改该图书状态为已借阅，输出“借阅成功”
	​		2）实现接口中的revert方法
	​			如果图书状态是可借阅状态，输出“该图书已归还”，否则，修改图书借阅状态为未借阅，并输出“还书成功”；
- （4）通过main函数测试。

		1）创建两个CollecitonBook对象book1和book2，分别输出book1和book2，并调用其equals方法判断两个对象是否相等；
	​	2）通过键盘输入整数，输入0，则对book1进行借阅，输入1，则对book1进行归还操作。
	​	

答案：  

```java

interface Library {
    abstract void borrow();
    abstract void revert();
}
class Book {
    private String name;
    private String publisher;

    public Book(String name, String publisher) {
        this.name = name;
        this.publisher = publisher;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    @Override
    public String toString() {
        return "Book{" +
                "name='" + name + '\'' +
                ", publisher='" + publisher + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Book book = (Book) o;
        return Objects.equals(name, book.name) &&
                Objects.equals(publisher, book.publisher);
    }
}

class CollectionBook extends Book implements Library{

    private String bId;//图书编号
    private boolean isBorrow;//是否借阅

    public CollectionBook(String name, String publisher, String number,boolean is) {
        super(name, publisher);
        bId = number;
        isBorrow = is;
    }

    @Override
    public void borrow() {
        if(isBorrow){
            System.out.println("该书已借阅");
        } else {
            isBorrow = true;
            System.out.println("借阅成功");
        }
    }

    @Override
    public void revert() {
        if(!isBorrow){
            System.out.println("该图书已经归还");
        } else {
            isBorrow = false;
            System.out.println("归回成功");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        CollectionBook book1= new CollectionBook("java","清华大学出版社","01",false);
        CollectionBook book2= new CollectionBook("c","清华大学出版社","02",true);
        boolean sc = book1.equals(book2);
        System.out.println("book1:"+book1);
        System.out.println("book2:"+book2);
        System.out.println(sc);
        Scanner scanner = new Scanner(System.in);
        System.out.println("输入你想要的操作:");
        System.out.println("0、则对book1进行借阅");
        System.out.println("1、则对book1进行归还操作");
        int choice=scanner.nextInt();
        switch(choice){
            case 0:
                book1.borrow();
                break;
            case 1:
                book1.revert();
                break;
            default:
                System.out.print("输入错误，重新输入");
        }
    }
}

```
