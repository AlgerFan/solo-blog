title: （1）什么是函数式编程——Webflux响应式编程利器
date: '2018-11-25 01:40:52'
updated: '2019-09-16 16:57:29'
tags: [lambda表达式, webflux响应式编程]
permalink: /articles/2018/11/25/1543081252012.html
---
![](https://img.hacpai.com/bing/20180224.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

- 学习webflux响应式前需要学习三个基础：

1. 函数式编程和lambda表达式
2. Stream流编程
3. Reactive stream 响应式流
4. 实战开发

- 接下来进入学习系列一

### 函数式编程和lambda表达式

#### 1. 什么是函数式编程

&emsp;&emsp;函数式编程是一种相对于命令式编程的一种编程范式，它不是一种具体的技术，而是一种如何搭建应用程序的方法论

#### 2. 为什么要使用函数式编程

- 能让我们以一种更加优雅的方式进行编程
- 函数式编程与命令式编程相比
  1）不同点：
  关注点不同，命令式编程我们关注的是怎么样做，而函数式编程关注的是做什么。
  2）优点：
  可以使代码更加的简短，更加的好读。

#### 3. lambda表达式初接触

&emsp;&emsp;具体看一个例子，求数组中的最大值，如果数据量太大，想要处理更高效，jdk8以前，只能自己创建线程池，自己拆分，而jdk8以后只需要加上parallel()，意思就是告诉它我要多线程的处理该数据，以此可以看到他的魅力

```java
public class MinDemo {
    public static void main(String[] args) {
        int[] arr = {15,24,12,451,156};
        int min = Integer.MAX_VALUE;
        for (int a :
                arr) {
            if (a < min) {
                min = a;
            }
        }
        System.out.println(min);

        //jdk8 lambda，parallel()多线程处理
        int min2 = IntStream.of(arr).parallel().min().getAsInt();
        System.out.println(min2);

    }
```

#### 4. 当然还有很多其他的特性，这里只简单介绍一下

- jdk8接口新特性
1.接口里只有一个要实现的方法，单一责任制
2.新增默认方法

- 函数接口
1.只需要知道输入输出的类型
2.支持链式操作

- 方法引用
1.静态方法引用
2.非静态方法引用
3.构造方法引用

- 级联表达式和柯里化
1.级联表达式是返回函数的函数
2.柯里化把多个参数的函数转换为只有一个参数的函数

- 变量引用
1.引用外边的变量必须是final类型

#### 5. 以下是函数式编程常用的接口

![2018111715515752.png](https://img.algerfan.cn/blog/image/20190619/cf43f593e2bc4126a14f0aec691ec5e8.png)
