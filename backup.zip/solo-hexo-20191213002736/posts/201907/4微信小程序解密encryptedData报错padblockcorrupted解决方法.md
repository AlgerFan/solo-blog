title: （4）微信小程序解密encryptedData 报错：pad block corrupted 解决方法
date: '2019-07-27 10:07:14'
updated: '2019-09-26 08:16:51'
tags: [微信小程序]
permalink: /articles/2019/07/27/1564193234521.html
---
![](https://img.hacpai.com/bing/20190425.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 问题描述：

在使用微信小程序登陆时进行解密数据，数据解密成功；但是在分享小程序到群组时，群组信息解密失败；**报错：pad block corrupted **

### 问题原因：

**session_key是有时效性的，但是每次的encryptedData数据又是需要实时的session_key，session_key用于解密encryptedData；**

解密encryptedData需要实时的session_key，且session_key要在wx.xxx()之前调用

### 说明图片：
如果你想了解更多，可以参考官方文档：[https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/signature.html](https://developers.weixin.qq.com/miniprogram/dev/framework/open-ability/signature.html)

![微信小程序解密encryptedData 报错1.jpg](https://img.algerfan.cn/blog/image/20190727/af4c608d89914d93ab2a4c0a351b4fa8.jpg)

![微信小程序解密encryptedData 报错2.jpg](https://img.algerfan.cn/blog/image/20190727/76d7b844212d4e7382655e4d01ef165d.jpg)

解密示例代码在这篇文章有介绍[（1）微信小程序+java后端实现登录](https://www.algerfan.cn/articles/2019/07/27/1564190547585.html)
