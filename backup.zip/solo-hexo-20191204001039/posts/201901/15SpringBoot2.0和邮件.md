title: （15）SpringBoot2.0 和邮件
date: '2019-01-15 16:23:14'
updated: '2019-10-16 14:20:19'
tags: [JavaWeb, Springboot, 邮件]
permalink: /articles/2019/01/15/1547540594012.html
---
![](https://img.hacpai.com/bing/20181021.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**示例源码下载：[https://github.com/AlgerFan/springBootExample](https://github.com/AlgerFan/springBootExample) ，欢迎star。**

![email.png](https://img.algerfan.cn/blog/image/20190918/4408db96a62441d793eff80ae1452b15.png)

邮件发送需要引入spring-boot-starter-mail，阿里云maven仓库可能导致不能导入依赖，可切换为默认仓库。

```
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-mail</artifactId>
</dependency>
```

定义MailProperties内容，配置在application.yml中

```
spring.mail.username=algerfan@qq.com
spring.mail.password=owejeujzhtlmbbd
spring.mail.host=smtp.qq.com
spring.mail.properties.mail.smtp.ssl.enable=true
```

自动装配JavaMailSender

测试邮件发送

```java
    @Autowired
    JavaMailSenderImpl mailSender;

    @Test
    public void contextLoads() {
        SimpleMailMessage message = new SimpleMailMessage();
        //邮件设置
        message.setSubject("通知-今晚搞事情");
        message.setText("今晚7:30搞事情");
        message.setTo("algerfan@163.com");
        message.setFrom("algerfan@qq.com");
        mailSender.send(message);
    }

    @Test
    public void test02() throws  Exception{
        //1、创建一个复杂的消息邮件
        MimeMessage mimeMessage = mailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
        //邮件设置
        helper.setSubject("通知-今晚搞事情");
        helper.setText("<b style='color:red'>今晚7:30搞事情</b>",true);
        helper.setTo("algerfan@163.com");
        helper.setFrom("algerfan@qq.com");
        //上传文件
        helper.addAttachment("1.jpg",new File("C:\\Users\\algerfan\\Pictures\\1.bmp"));
        helper.addAttachment("2.jpg",new File("C:\\Users\\algerfan\\Pictures\\11042111.bmp"));
        mailSender.send(mimeMessage);
    }
```



