title: （转）（5）创建本地镜像(commit、Dockerfile)
date: '2019-07-26 22:02:22'
updated: '2019-10-18 16:26:28'
tags: [docker, 转载好文]
permalink: /articles/2019/07/26/1564149742396.html
---
![](https://img.hacpai.com/bing/20190110.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> 作者：孤天浪雨
地址：https://blog.csdn.net/u010246789

在[（3）Docker容器内信息获取、命令的执行、容器的导入和导出](https://www.algerfan.cn/articles/2019/07/26/1564133511398.html)中，将一个由镜像导出的tar包，本地导入tar包为镜像，也是本地创建镜像的一种方式。
通常我们自己制作镜像都是以某一镜像为基础，在此之上安装或者定制自己需要的镜像，推荐使用Dockerfile。

## 一、commit命令创建本地镜像

**这边我们准备在centos为基础的镜像上，安装jdk，并创建一个txt文件，然后使用commit命令打成新镜像。**

* `docker run -t -i centos`：启动一个centos的交互性容器。
* 干净的centos容器中没有jdk，我们马上要安装：`yum install java`。
* 记录[root@ae56f6cad215 /]中@后面的Hash值：`ae56f6cad215`，后面会用到。

![docker创建镜像1.jpg](https://img.algerfan.cn/blog/image/20190726/c08099077c6f4495b16fd7538e1aa238.jpg)

* `java version`：此时我们已经安装好了JDK1.8。
* `touch test_commit_image.txt`：创建一个txt文件。
* `exit`：退出容器。

![docker创建镜像2.jpg](https://img.algerfan.cn/blog/image/20190726/6363417a38f94931945f248bafdbd35c.jpg)

* `docker commit -m="commit jdk" --author="gutianlangyu" ae56f6cad215 gutianlangyu/commit_jdk:v1`：使用commit命令将容器里的所有修改提交到本地库中，形成以一个全新的镜像，会返回新镜像的完整ID。

    * 完整ID可以通过`docker ps -l -q`(用于获取最近创建的容器ID)命令得到。

    * `-m`：描述我们此次创建image的信息。

    * `--author`：用来指定作者。

    * `ae56f6cad215`：被修改的基础镜像ID。

    * `gutianlangyu/commit_jdk:v1`：仓库名/镜像名:TAG名。

![docker创建镜像3.jpg](https://img.algerfan.cn/blog/image/20190726/d6d475da282b4ac2bf85b21cf2d79ba3.jpg)

**检查新镜像：如下图，镜像5e0f7204704a中，已经有了jdk1.8、test_commit_image.txt**

![docker创建镜像4.jpg](https://img.algerfan.cn/blog/image/20190726/ef0132a165ad4ae58627843c2c7cd18b.jpg)

## 二、Dockerfile创建镜像

**将需要对镜像进行的操作全部写到一个文件中，然后使用docker build命令从这个文件中创建镜像。这种方法可以使镜像的创建变得透明和独立化，并且创建过程可以被重复执行。Dockerfile文件以行为单位，行首为Dockerfile命令，命令都是大写形式，其后紧跟着的是命令的参数。
Dockerfile文件实例，本例子并没有实际意义，只是为了将知识点都覆盖到,具体含义请看文末附录一：**

![docker创建镜像5.jpg](https://img.algerfan.cn/blog/image/20190726/e5678239f5424134ae0a0d0b38d15ac9.jpg)

```java
#Version 1.0.1
FROM centos:latest

MAINTAINER ***u "***u@163.com"

#设置root用户为后续命令的执行者
USER root

#执行操作
RUN yum update -y
RUN yum install -y java

#使用&&拼接命令
RUN touch test.txt && echo "abc" >>abc.txt

#对外暴露端口
EXPOSE 80 8080 1038

#添加文件
ADD abc.txt /opt/

#添加文件夹
ADD /webapp /opt/webapp

#添加网络文件
ADD https://www.baidu.com/img/bd_logo1.png /opt/

#设置环境变量
ENV WEBAPP_PORT=9090

#设置工作目录
WORKDIR /opt/

#设置启动命令
ENTRYPOINT ["ls"]

#设置启动参数
CMD ["-a", "-l"]

#设置卷
VOLUME ["/data", "/var/www"]

#设置子镜像的触发操作
ONBUILD ADD . /app/src
ONBUILD RUN echo "on build excuted" >> onbuild.txt
```

### 使用build命令来构建镜像：

* `docker build -t gutianlangyu/test:build_dockerfile_test .`

![docker创建镜像6.jpg](https://img.algerfan.cn/blog/image/20190726/e206be426a5b46d4857d4a716abc3665.jpg)

![docker创建镜像7.jpg](https://img.algerfan.cn/blog/image/20190726/d4421180c53344b2b10191903b13b877.jpg)

* `-t`参数用来指定镜像的命名空间、仓库名及TAG。这个值可以在镜像创建成功之后通过tag命令修改。

* 事实上是创建一个镜像的两个名称引用，指向的是同一个镜像实体`bc27aeae40dd`，如下图：

![docker创建镜像8.jpg](https://img.algerfan.cn/blog/image/20190726/3bf58525596845b8bab4b156f5cf5264.jpg)

* 紧跟-t参数的是Dockerfile文件所在的相对目录，本例使用的是当前目录，即“.”

## 三、Dockerfile-GitHub

**可以把dockerfile放在github上，我的地址是https://github.com/gubaijin/docker/blob/master/Dockerfile,clone地址是https://github.com/gubaijin/docker.git
执行命令：docker build -t gutianlangyu/test:build_dockerfile_test_github https://github.com/gubaijin/docker.git，你们直接执行也可以成功。**

![docker创建镜像9.jpg](https://img.algerfan.cn/blog/image/20190726/e170209f6ce24f7eae17a7f55200468d.jpg)

![docker创建镜像10.jpg](https://img.algerfan.cn/blog/image/20190726/126be54296404816aa52569439e4d92a.jpg)

## 附录一：

* `FROM`：指定待扩展的父级镜像(基础镜像)。除了注释以外，在文件开头必须是一个FROM指令，接下来的指令便在这个父级镜像的环境中运行，直到遇到下一个FROM指令。通过添加多个FROM命令，可以在同一个Dockerefile文件中创建多个镜像。

* `MAINTAINER`：声明创建的镜像的作者信息。用户名、邮箱。非必须。

* `RUN`：用来修改镜像的命令，常用来安装库、程序以及配置程序。一条RUN指令执行完毕后，会在当前镜像上创建一个新的镜像层，接下来对的指令会在新的镜像上继续执行。RUN 语句有两种形式：

    * `RUN yum update`：是在/bin/sh环境中执行的指令的命令

    * `RUN ["yum", "update"]`：直接使用系统调用exec来执行行。

    * `RUN yum update && yum install nginx`：使用&&符号将多条命令连接在同一条RUN语句中。

* `EXPOSE`：用来指明容器内进程对外开放的端口，多个端口之间使用空格隔开。运行容器时，通过参数-P(大写)即可将EXPOSE里所指定的端口映射到主机上另外的随机端口，其他容器或主机就可以通过映射后的端口与此容器通信。同时，我们也可以通过-p(小写)参数将Dockerfile中EXPOSE中没有列出的端口设置成公开的。

* `ADD`：向新镜像中添加文件，这个文件可以是一个主机文件，也可以是一个网络文件，也可以使一个文件夹。

    * 第一个参数：源文件（夹）。如果是相对路径，它必须是相对于Dockerfile所在目录的相对路径。如果是URL，会先下载下来，再添加到镜像里去。

    * 第二个参数：目标路径。如果源文件是主机上zip或者tar形式的压缩文件，Docker会先解压缩，然后将文件添加到镜像的指定位置。如果源文件是一个通过URL指定的网络压缩文件，则不会解压。

* `VOLUME`：在镜像里创建一个指定路径(文件或文件夹)的挂载点，这个容器可以来自主机或者其它容器。多个容器可以通过同一个挂载点共享数据，即便其中一个容器已经停止，挂载点也仍热可以访问。

* `WORKDIR`：为接下来执行的指令指定一个新的工作目录，这个目录可以使绝对目录，也可以是相对目录。根据需要，WORKDIR可以被多次指定。当启动一个容器时，最后一条WORKDIR指令所指的目录将作为容器运行的当前工作目录。

* `ENV`：设置容器运行的环境变量。在运行容器的时候，通过-e参数可以修改这个环境变量值，也可以添加新的环境变量：

`docker run -e WEBAPP_PORT=8000 -e WEBAPP_HOST=www.example.com ...`

* `CMD`：用来设置启动容器时默认运行的命令。

* `ENTRYPOINT`：与CMD类似，也是用来指定容器启动时的默认运行的命令。区别在于：运行容器时添加在镜像之后的参数，对ENTRYPOINT是拼接，CMD是覆盖。

    * `ENTRYPOINT [ "ls", "-l"]`

    * `docker run centos ==> docker run centos ls -l`

    * `docker run centos -a ==> docker run centos ls -l -a`

        * 我们在运行容器的时候可以通过--entrypoint来覆盖Dockerfile中的指定：`docker run gutianlangyu/test --entrypoint echo "hello world"`

* `USER`：为容器的运行及接下来RUN、CMD、ENTRYPOINT等指令的运行指定用户或UID。

* `ONBUILD`：触发器指令。构建镜像时，Docker的镜像构建器会将所有的ONBUILD指令指定的命令保存到镜像的元数据中，这些命令在当前镜像的构建过程中并不会执行。只有心的镜像使用FROM指令指定父镜像为这个镜像时，便会触发执行。

    * 使用FROM以这个Dockerfile构建出的镜像为父镜像，构建子镜像时：

    * ONBUILD ADD . /app/src：自动执行ADD . /app/src
