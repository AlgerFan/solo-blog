title: （1）CentOS 7 安装、卸载Docker CE以及开启远程访问
date: '2019-07-26 16:44:37'
updated: '2019-09-01 08:59:54'
tags: [docker]
permalink: /articles/2019/07/26/1564130677700.html
---
![](https://img.hacpai.com/bing/20180801.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 前言

Docker 使用越来越多，安装也很简单，本次记录一下基本的步骤。

Docker 目前支持 CentOS 7 及以后的版本，内核要求至少为 3.10。

### 环境说明

CentOS 7（Minimal Install）

```java
$ cat /etc/redhat-release 
CentOS Linux release 7.6.1810 (Core) 
```

## 准备工作

### 安装pytz模块

如果你的程序要考虑时区，可以使用**pytz**
```java
$ sudo pip install pytz
```

### 卸载旧版本

旧版本的 Docker 被叫做 `docker` 或 `docker-engine`。

```java
$ sudo yum remove docker docker-common docker-selinux docker-engine -y
```

旧版本的内容在 `/var/lib/docker` 下，目录中的镜像(images), 容器(containers), 存储卷(volumes), 和 网络配置（networks）都可以保留。

Docker CE 包，目前的包名为 `docker-ce`。

## 安装

### 安装准备

为了方便添加软件源，支持 devicemapper 存储类型，安装如下软件包

```java
$ sudo yum install -y yum-utils device-mapper-persistent-data lvm2 -y
```

### 安装 Docker

更新一下 yum 软件源的缓存，并安装 Docker。

```java
$ sudo yum update
$ sudo yum install docker -y
```

至此，Docker 已经安装完成了。

> **`注意`**
> 
> 默认的 docker 组是没有用户的（也就是说需要使用 sudo 才能使用 docker 命令）。  
> 您可以将用户添加到 docker 组中（此用户就可以直接使用 docker 命令了）。

加入 docker 用户组命令

```java
$ sudo usermod -aG docker USER_NAME
```

用户更新组信息后，重新登录系统即可生效。

### 启动 Docker

如果想添加到开机启动

```java
$ sudo systemctl enable docker
```

启动 docker 服务

```java
$ sudo systemctl start docker
```

### 验证安装

验证 Docker CE 安装是否正确，可以运行 `hello-world` 镜像

```java
$ sudo docker run hello-world
```

## 卸载 Docker

### 卸载 Docker CE

```java
$ sudo systemctl stop docker
$ sudo pip uninstall docker -y
```

### 删除本地文件

注意，docker 的本地文件，包括镜像(images), 容器(containers), 存储卷(volumes)等，都需要手工删除。默认目录存储在 `/var/lib/docker`。

```java
$ sudo rm -rf /var/lib/docker
```

## 开启远程访问

1. 在vi /usr/lib/systemd/system/docker.service，配置远程访问。主要是在[Service]这个部分，将其中`ExecStart=/usr/bin/dockerd-current` 后加上`-H tcp://0.0.0.0:2375 -H unix://var/run/docker.sock -H tcp://0.0.0.0:7654 `：

```java
ExecStart=/usr/bin/dockerd-current -H tcp://0.0.0.0:2375 -H unix://var/run/docker.sock -H tcp://0.0.0.0:7654 \
          --add-runtime docker-runc=/usr/libexec/docker/docker-runc-current \
          --default-runtime=docker-runc \
          --exec-opt native.cgroupdriver=systemd \
          --userland-proxy-path=/usr/libexec/docker/docker-proxy-current \
          --init-path=/usr/libexec/docker/docker-init-current \
          --seccomp-profile=/etc/docker/seccomp.json \
          $OPTIONS \
          $DOCKER_STORAGE_OPTIONS \
          $DOCKER_NETWORK_OPTIONS \
          $ADD_REGISTRY \
          $BLOCK_REGISTRY \
          $INSECURE_REGISTRY \
	  $REGISTRIES
```
此处默认2375为主管理端口，`unix://var/run/docker.sock`用于本地管理，7654是备用端口.
2. docker重新读取配置文件，重启docker服务

```java
[root@TK-PMS-187 ~]# systemctl daemon-reload
[root@TK-PMS-187 ~]# systemctl restart docker
```
3. 查看docker进程，发现docker 守护进程在已经监听2375的tcp端口

```
[root@iZuf6grf5xaa42v2hd6w52Z ~]# ps -ef | grep docker 
root      3975  8527  0 09:01 pts/2    00:00:00 grep --color=auto docker
root      8258     1  0 08:30 ?        00:00:02 /usr/bin/dockerd-current -H tcp://0.0.0.0:2375 -H unix://var/run/docker.sock -H tcp://0.0.0.0:7654 --add-runtime docker-runc=/usr/libexec/docker/docker-runc-current --default-runtime=docker-runc --exec-opt native.cgroupdriver=systemd --userland-proxy-path=/usr/libexec/docker/docker-proxy-current --init-path=/usr/libexec/docker/docker-init-current --seccomp-profile=/etc/docker/seccomp.json --selinux-enabled --log-driver=journald --signature-verification=false --storage-driver overlay2
root      8264  8258  0 08:30 ?        00:00:01 /usr/bin/docker-containerd-current -l unix:///var/run/docker/libcontainerd/docker-containerd.sock --metrics-interval=0 --start-timeout 2m --state-dir /var/run/docker/libcontainerd/containerd --shim docker-containerd-shim --runtime docker-runc --runtime-args --systemd-cgroup=true
```
4. 通过本地idea连接，来访问服务器上的centos7的docker服务，访问成功。

![docker安装.jpg](https://img.algerfan.cn/blog/image/20190731/b159a8bb4ce04bbb8d1d2c676c5699aa.jpg)

## 结论

至此，这些就是CentOS 7 下 安装、卸载 Docker CE、开启远程访问的全部步骤。
