title: （转）（3）Docker容器内信息获取、命令的执行、容器的导入和导出
date: '2019-07-26 17:31:51'
updated: '2019-10-18 16:25:51'
tags: [docker, 转载好文]
permalink: /articles/2019/07/26/1564133511398.html
---
![](https://img.hacpai.com/bing/20181020.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

> 作者：孤天浪雨
地址：https://blog.csdn.net/u010246789

## 一、依附容器

依附操作attach通常用在由docker start或者docker restart启动的交互型容器中。由于docker start启动的交互型容器并没有具体终端可以依附，而容器本身是可以接收用户交互的，这时就需要通过attach命令来将终端依附到容器上。

* `docker start docker_run`：先启动docker_run容器。
* 启动后`docker ps`可以看到启动的容器。
* 执行`docker attach docker_run`，终端就已经依附到了容器上，ls显示的就是容器中的目录内容。
* 注意：后台型容器是无法依附终端的，因为它本身就不接受用户交互输入。

![容器信息获取1.jpg](https://img.algerfan.cn/blog/image/20190726/5132be83acf84628b738533f3f9e3a51.jpg)


## 二、查看容器日志

* 首先创建一个不断输出一些内容的后台型容器，我命名为docker_logs，是一个包含循环输出的自然数容器：`docker run -d --name docker_logs centos /bin/bash -c "for((i=0;1;i++));do echo $i;sleep 1;done;`

![容器信息获取2.jpg](https://img.algerfan.cn/blog/image/20190726/e6b01220d9ee42af952f8127632d6801.jpg)

* 进入Tomcat容器：` docker exec -it 1fe05876c6d3 /bin/bash`
* `docker logs -f docker_logs:`此命令默认情况下是输出从容器启动到执行命令时的所有输出，但是之后的输出就不显示了，-f命令会实时显示日志。
* `docker logs -f --tail=5 docker_logs:–tail`是控制logs输出的行数为最后5行。

## 三、查看容器进程

`docker top docker_logs`：可以查看容器中正在运行的进程。

![容器信息获取3.jpg](https://img.algerfan.cn/blog/image/20190726/b4ffca37053b4535867ec3842b52b2ee.jpg)


## 四、查看容器信息

* `docker inspect [NAME]/[CONTAINER ID]`：用于查看容器的配置信息，包含容器名、环境变量、运行命令、主机配置、网络配置和数据卷配置等：

![容器信息获取4.jpg](https://img.algerfan.cn/blog/image/20190726/69285db9353441de9094bbe84e313f64.jpg)

* -f或--format格式化标志，可以查看指定部分的信息。

    * `docker inspect --format='{{.State.Running}}' [NAME]/[CONTAINER ID]`:查看容器的运行状态。
    * `docker inspect --format='{{.NetworkSettings.IPAddress}} [NAME]/[CONTAINER ID]'`:查看容器的IP地址。
    * **同时查看多个信息**：`docker inspect --format '{{.Name}} {{.State.Running}}' [NAME]/[CONTAINER ID]`:查看容器名和运行状态。 
![容器信息获取5.jpg](https://img.algerfan.cn/blog/image/20190726/61d1766276ec49dca5a1c4b9cfecde20.jpg)

## 五、容器内执行命令
在容器启动的时候，通常需要指定其需要执行的程序，然而有时候我们需要在容器运行之后中途启动另一个程序。从Docker1.3开始，我们可以用docker exec命令在容器中运行新的任务，它可以创建两种任务：后台型和交互型。

* `docker exec -d docker_logs touch /etc/exec_new_file：-d:`后台型，并在容器中创建一个文件。 

![容器信息获取6.jpg](https://img.algerfan.cn/blog/image/20190726/39dab6a12f054f2ab9af3fc4802fae24.jpg)

## 容器的导入和导出

> 用户不仅可以把容器提交到公共服务器上，还可以将容器导出到本地文件系统中。同样，我们也可以将导出的容器重新导入到Docker运行环境中。导入：`import`,导出：`export`。

* `docker export docker_logs > docker_logs_export.tar`：把容器的文件系统以tar包的格式导出到标准输出。 

![容器信息获取7.jpg](https://img.algerfan.cn/blog/image/20190726/1246b3b050f44a31b55f3d8b57e1b6e3.jpg)

* `cat docker_logs_export.tar | docker import - [res]:[tag]`：把打包的容器导入为一个镜像，res代表镜像。tag代表标记。 

![容器信息获取8.jpg](https://img.algerfan.cn/blog/image/20190726/f052268cb9934b1da767e0adce633c1c.jpg)

* `docker import url res:tag`：还可以通过一个url链接来导入网络上的容器。
