title: （2）Spring Security初试
date: '2019-07-10 18:31:52'
updated: '2019-07-25 21:24:30'
tags: [权限管理]
permalink: /articles/2019/07/10/1562754712013.html
---
### 一、Spring Security介绍
Spring Security主要组件图
![Spring Security-主要组件图.jpg](https://img.algerfan.cn/blog/image/20190725/9255e4fd6d1c4810b76558650fd64ad1.jpg)
Spring Security-核心处理流程图
![Spring Security-核心处理流程图.jpg](https://img.algerfan.cn/blog/image/20190725/f5a48d250895446691bc9ae3f2e36dfd.jpg)

### 二、Spring Security常用权限拦截器 

- SecurityContextPresistenceFilter
- LogoutFilter
- AbstractAuthenticationProcessingFiter
- DefaultLoginPageGeneratingFilter
- BasicAuthenticationFilter
- SecurityContextHolderAwareRequestFilter
- RememberMeAuthenticationFilter
- AnonymousAuthenticationFilter
- ExceptionTranslationFilter
- SessionManagementFilter
- FilterSecurityInterceptor
- FilterChainProxy

### 三、基于SpringBoot的SpringSecurity环境搭建与验证

话不多少，直接上代码

maven依赖

```java

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

```

SpringSecurity配置

```java

package cn.algerfan.springsecurity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * <p>
 *  SpringSecurity配置
 * </p>
 *
 * @author algerfan
 * @since 2019/7/8 21
 */
@Configurable
@EnableWebSecurity
public class SpringSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private MyUserService myUserService;

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        //管理员
        auth.inMemoryAuthentication().withUser("admin").password("123456").roles("ADMIN");
        //普通用户
        auth.inMemoryAuthentication().withUser("test").password("123456").roles("user");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .antMatchers("/").permitAll()
                .anyRequest().authenticated()
                .and().logout().permitAll()
                .and().formLogin();
    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/js/**", "/css/**", "/img/**");
    }

    @Bean
    public static PasswordEncoder passwordEncoder(){
        return NoOpPasswordEncoder.getInstance();
    }
}

```

测试代码

```java

package cn.algerfan.springsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.access.prepost.PreFilter;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *
 * </p>
 *
 * @author algerfan
 * @since 2019/7/8 21
 */
@SpringBootApplication
@RestController
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SpringSecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringSecurityApplication.class, args);
    }

    @RequestMapping("/")
    public String spring() {
        return "hello spring";
    }

    @RequestMapping("/hello")
    public String springSecurity() {
        return "hello springSecurity";
    }

    @PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping("/role")
    public String role() {
        return "admin auth";
    }

    /**
     *     @PreAuthorize 在方法之前校验
     *     @PostAuthorize 在方法调用完之后校验
     */
    @PreAuthorize("#id>10 and principal.username.equals(username) and #user.username.equals('abcd')")
    @PostAuthorize("returnObject%2==0")
    @RequestMapping("/test")
    public String test(Integer id, String username, User user) {
        return "admin auth";
    }

    /**
     *     @PreFilter 在方法之前校验
     *     @PostFilter 在方法调用完之后校验
     */
    @PreFilter("filterObject%2==0")
    @PostFilter("filterObject%4==0")
    @RequestMapping("/test2")
    public List<Integer> test2(List<Integer> idList) {
        return idList;
    }

}


```