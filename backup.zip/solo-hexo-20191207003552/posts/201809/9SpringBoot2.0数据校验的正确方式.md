title: （9）Spring Boot2.0 数据校验的正确方式
date: '2018-09-13 09:31:14'
updated: '2019-10-03 15:42:09'
tags: [JavaWeb, Springboot, 数据校验]
permalink: /articles/2018/09/13/1536802274012.html
---
![](https://img.hacpai.com/bing/20180801.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**示例源码下载：[https://github.com/AlgerFan/springBootExample](https://github.com/AlgerFan/springBootExample) ，欢迎star。**

### 一、前言

  使用springboot也很长时间了，也做过几个小项目，最近有时间总结一下，话不多说，本篇介绍一下springboot数据校验，我还记得当初接触springboot的时候并不知道可以这样做，下面直接代码演示

### 二、代码演示

Controller

```java
/**
 * @author AlgerFan
 * @date Created in 2019/1/25 16
 * @Description SpringBoot 表单数据校验
 */
@Controller
public class UsersController {
	/**
	 * 必须传递user这个对象，要不然会报错
	 * @param users
	 */
	@RequestMapping("/addUser")
	public String showPage(@ModelAttribute("user") Users users){
		return "add";
	}
	
	/**
	 * 完成用户添加
	 * @Valid 开启对Users对象的数据校验
	 * @ModelAttribute("user") 将错误结果显示在页面上
	 * BindingResult:封装了校验的结果
	 */
	@RequestMapping("/save")
	public String saveUser(@ModelAttribute("user") @Valid Users users, BindingResult result){
		if(result.hasErrors()){
			return "add";
		}
		System.out.println(users);
		return "ok";
	}
}

```

User

```java
public class Users {
	@NotBlank(message="用户名不能为空") //非空校验
	@Length(min=2,max=6,message="最小长度为2位，最大长度为6位")
	private String name;
	@NotEmpty
	private String password;
	@Min(value=15)
	private Integer age;
	@Email
	private String email;

	//此处省略Getter和Setter以及toString方法,也可用Data注解

}
```

HTML

```html
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"
	  xmlns:th="http://www.thymeleaf.org">
<head>
<meta charset="UTF-8">
<title>添加用户</title>
</head>
<body>
	<form th:action="@{/save}" method="post">
		用户姓名：<input type="text" name="name"/><span th:errors="${user.name}" style="color: red; "></span><br/>
		用户密码：<input type="password" name="password" /><span th:errors="${user.password}" style="color: red; "></span><br/>
		用户年龄：<input type="text" name="age" /><span th:errors="${user.age}" style="color: red; "></span><br/>
		用户邮箱：<input type="text" name="email" /><span th:errors="${user.email}" style="color: red; "></span><br/>
		<input type="submit" value="OK"/>
	</form>
</body>
</html>
```

### 三、测试结果演示

![20190125163145.png](https://img.algerfan.cn/blog/image/20190406/fd29f19b01fc444099f3221f24559eaa.png)
