title: deepin15.7安装与卸载MySQL、修改默认编码等
date: '2018-10-24 06:32:48'
updated: '2019-09-01 08:59:19'
tags: [Linux, MySQL]
permalink: /articles/2018/10/24/1540333968012.html
---
![](https://img.hacpai.com/bing/20180419.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、首先安装MySQL

#### 1. 安装前更新一下仓库，输入命令：`sudo apt-get update`

	`algerfan@algerfan:~$ sudo apt-get autoremove --purge mysql-server-5.7`

#### 2. 输入命令：`sudo apt-get install mysql-server mysql-client`

    安装MySQL数据库程序和命令行管理工具客户端
    
    1）接下来可能会提示你输入root帐号密码，输入即可
    2）若没有提示，也不要着急
    	解决方法：在/etc/mysql/下找到debian.conf文件获取用户名和密码
    	`algerfan@algerfan:~$ sudo vi /etc/mysql/debian.cnf`
![20181023215408445.png](https://img.algerfan.cn/blog/image/20190619/3dd3dea17577488c8da040905ca70254.png)

#### 3. 登录之后就可以设置root的用户登录密码了

	`use mysql;`
	  
	`update user set authentication_string=PASSWORD("自定义密码") where user='root';`
	  
	`update user set plugin="mysql_native_password";`
	  
	`flush privileges;`

#### 4. 设置mysql

	1）将mysql加入到系统服务
	`chkconfig --add mysql`
	2）将mysql设置开机启动
	`chkconfig mysql on`
	注意：在这里可能chkconfig没有安装，如果是的话 ，则需要安装chkconfig命令：
	`sudo apt-get install chkconfig`


### 二、卸载MySQL

#### 1. 查看MySQL的版本号

	`algerfan@algerfan:~$ mysql -V`
	mysql  Ver 14.14 Distrib 5.7.21, for Linux (x86_64) using  EditLine wrapper

#### 2. 卸载MySQL

	`algerfan@algerfan:~$ sudo apt-get autoremove --purge mysql-server-5.7`
	   
	卸载其他软件包
	
	`root@lsj-pc:/home/lsj# apt-get autoremove mysql-server`
	
	`root@lsj-pc:/home/lsj# apt-get remove mysql-common`

#### 3. 清除配置文件

	`root@lsj-pc:/home/lsj# dpkg -l |grep ^rc|awk '{print $2}' |sudo xargs dpkg -P`

### 三、修改默认编码为utf-8

#### 1. 登陆后查看数据库当前编码：`SHOW VARIABLES LIKE 'character%';`

#### 2. 修改默认编码为utf-8

1) 在终端中输入 `sudo gedit /etc/mysql/mysql.conf.d/mysqld.cnf`
打开mysqld.cnf 文件，在lc-messages-dir = /usr/share/mysql 语句后添加 character-		   set-server=utf8 语句
![20181024164937670.png](https://img.algerfan.cn/blog/image/20190619/47ff506d3dc14b628c9da9873e59534e.png)
1) 在终端输入 `sudo gedit /etc/mysql/conf.d/mysql.cnf`
打开mysql.cnf配置文件，如图添加代码：default-character-set=utf8
![20181024165046653.png](https://img.algerfan.cn/blog/image/20190406/f587d73d18c743db8f22bb54d9134383.png)
1) 在终端中输入  /etc/init.d/mysql restart 
重启MySQL服务

### 四、查询MySQL的一些命令

#### 1. 停止MySQL数据库服务：

`$ sudo systemctl stop mysql.service`

#### 2. 启动MySQL数据库服务：

`$ sudo systemctl start mysql.service`

#### 3. 重启MySQL数据库服务：

`$ sudo systemctl restart mysql.service`
或者`$ sudo /etc/init.d/mysql restart`

#### 4. 查看MySQL运行状态：

`$ sudo systemctl status mysql.service`
