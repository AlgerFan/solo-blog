title: Windows脱坑，MySQL5.7安装版修改编码，亲测可用
date: '2018-11-19 00:06:32'
updated: '2019-07-21 09:39:26'
tags: [MySQL, 脱坑记]
permalink: /articles/2018/11/19/1542557192012.html
---
![](https://img.hacpai.com/bing/20180620.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

- 最近Linux转win10，安装MySQL时修改编码无效，网上找了很多方案没一个成功的，在此特此记录一下。
- 注：MySQL5.7安装版下载地址[https://dev.mysql.com/downloads/mysql/](https://dev.mysql.com/downloads/mysql/) ，
进入后点击
![20181118155141903.png](https://img.algerfan.cn/blog/image/20190406/ecbe38c3039f4255b07fa8ef0a873d79.png)
下载旧版本5.7

#### 一、 首先说一下网上的方案，在MySQL安装目录添加my.ini文件，文件内容为：

	```
	[client]
	default-character-set=utf8
	[mysqld]
	character-set-server=utf8
	```
修改后重启MySQL，登录查看编码`show variables like '%char%';`
![2018111815544719.png](https://img.algerfan.cn/blog/image/20190619/28c4b3ce803f4b098c032d90347d46e2.png)
看到character_set_database和character_set_server依然是latin1，那么问题来了，这两个怎么改编码？

#### 二、解决方案

最终我发现在C盘有一个隐藏文件夹ProgramData，里面找到MySQL下还有一个my.ini，

1. 找到[mysql]，在# default-character-set=的下一行添加
`default-character-set=utf8`
2. 找到[mysqld]，在# character-set-server=的下一行添加`character-set-server=utf8`
再次重启MySQL，查看编码，修改成功
![20181118160150433.png](https://img.algerfan.cn/blog/image/20190619/cd0696f6f18d44d69cd226e391b8bdc4.png)