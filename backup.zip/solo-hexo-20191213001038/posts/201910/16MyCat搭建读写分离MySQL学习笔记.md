title: （16）MyCat  搭建、读写分离——MySQL学习笔记
date: '2019-10-20 10:31:06'
updated: '2019-10-29 20:54:06'
tags: [MySQL]
permalink: /articles/2019/10/20/1571538666316.html
---
![](https://img.hacpai.com/bing/20180423.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 一、安装 mycat

解压缩: tar -zxf mycat-xxxx.tar.gz

### 1.Master  提供可被 Mycat 访问的用户

在 Mycat 中通过 Master 数据库的 root 用户访问 Master 数据库。
grant all privileges on *.* to ‘username’@’ip’ identified by ‘password’ with grant option;

例如：

`grant all privileges on *.* to 'mycat'@'%' identified by 'mycat' with grant option;`

### 2.上传 mycat

Mycat-server-1.6-RELEASE-20161028204710-linux.tar.gz

### 3.解压缩

tar -zxf Mycat-server-1.6-RELEASE-20161028204710-linux.tar.gz

## 二、Mycat  配置文件详解

Mycat 所有的配置文件,都在应用的 conf 目录中.

### 1.rule.xml

用于定义分片规则的配置文件。主要是查看，很少修改。

mycat 默认的分片规则: 以 500 万为单位,实现分片规则。

逻辑库 A 对应 dataNode - db1 和 db2. 1-500 万保存在 db1 中，500 万零 1 到 1000 万保存。在 db2 中，1000 万零 1 到 1500 万保存在 db1 中。依次类推。

```
<tableRule name="auto-sharding-long">
    <rule>
        <columns>id</columns>
        <algorithm>rang-long</algorithm>
    </rule>
</tableRule>
```

crc32slot 规则: 在 CRUD 操作时，根据具体数据的 crc32 算法计算，数据应该保存在哪一个 dataNode 中。算法类似模运算。

```
<tableRule name="crc32slot">
    <rule>
        <columns>id</columns>
        <algorithm>crc32slot</algorithm>
    </rule>
</tableRule>
```

### 2.schema.xml

用于定义逻辑库和逻辑表的配置文件。在配置文件中可以定义读写分离,逻辑库，逻辑
表，dataHost,dataNode 等信息。
配置文件解释:

**1）标签 schema**

配置逻辑库的标签

* 属性 name
  逻辑库名称
* 属性 checkSQLschema
  是否检测 SQL 语法中的 schema 信息
  如: Mycat 逻辑库名称 A, dataNode 名称 B
  SQL : select * from A.table;
  checkSQLschema 值是 true, Mycat 发送到数据库的 SQL 是 select * from table;
  checkSQLschema 值是 false,Mycat 发送的数据库的 SQL 是 select * from A.table;
* sqlMaxLimit
  Mycat 在执行 SQL 的时候，如果 SQL 语法中没有 limit 子句。自动增加 limit 子句。避免一次
  性得到过多的数据,影响效率。 limit 子句的限制数量默认配置为 100。如果 SQL 中有具体的 limit
  子句，当前属性失效。
  SQL : select * from table . mycat 解析后: select * from table limit 100
  SQL : select * from table limit 10 . mycat 不做任何操作修改.

**2）标签 table**

定义逻辑表的标签，如果需要定义多个逻辑表，编写多个 table 标签。要求逻辑表的表
名和物理表（MySQL 数据库中真实存在的表）的表名一致。

* 属性 name
  逻辑表名
* 属性 dataNode
  数据节点名称. 配置文件中后续需要定义的标签（即物理数据库中的 database 名称）.
  多个名称使用逗号分隔.
  多个 database 定义后，代表分库。
* 属性 rule
  分片规则名称.具体的规则名称参考 rule.xml 配置文件.
  SQL 语句发送到 Mycat 中后，Mycat 如何计算，应该将当期的 SQL 发送到哪一个物理数
  据库管理系统或物理 database 中。

**3）标签 dataNode**

定义数据节点的标签， 定义具体的物理 database 信息的。

* 属性 name
  数据节点名称, 是定义的逻辑名称,对应具体的物理数据库 database
* 属性 dataHost
  引用 dataHost 标签的 name 值,代表使用的物理数据库所在位置和配置信息.
* 属性 database
  在 dataHost 物理机中,具体的物理数据库 database 名称.

**4）dataHost  标 签**

定义数据主机的标签， 就是物理 MySQL 真实安装的位置。

* 属性 name
  定义逻辑上的数据主机名称
* 属性 maxCon/minCon
  最大连接数, max connections
  最小连接数, min connections
* 属性 dbType
  数据库类型 : MySQL 数据库
* 属性 dbDriver
  数据库驱动类型, native,使用 mycat 提供的本地驱动.

**5）dataHost  子标签 writeHost**

写数据的数据库定义标签. 实现读写分离操作.

* 属性 host
  数据库命名
* 属性 url
  数据库访问路径
* 属性 user
  数据库访问用户名
* 属性 password
  访问用户密码

### 3.server.xml

配置 Mycat 服务信息的，也可使用默认的。
如: Mycat 中的用户,用户可以访问的逻辑库,可以访问的逻辑表,服务的端口号等。
常见修改内容：

```xml
<property name="serverPort">8066</property> <!-- Mycat 服务端口号 -->
<property name="managerPort">9066</property><!-- Mycat 管理端口号 -->
<user name="root"><!-- mycat 用户名 -->
    <property name="password">密码</property>
    <property name="schemas">用户可访问逻辑库名</property>
    <!-- 表级 DML 权限设置 -->
    <!-- 不检查权限
    <privileges check="false">
        <schema name="逻辑库名" dml="0110" >
            <table name="逻辑表名" dml="0000"></table>
            <table name="tb02" dml="1111"></table>
        </schema>
    </privileges>
    -->
</user>
<user name="user"><!-- 其他用户名 -->
    <property name="password">密码</property>
    <property name="schemas">可访问逻辑库名</property>
    <property name="readOnly">是否只读</property>
</user>
```

### 4.启动 Mycat  命令

bin/mycat start

### 5.停止命令

bin/mycat stop

### 6.重启命令

bin/mycat restart

### 7.查看 Mycat 状态

bin/mycat status

### 8.访 问 方 式

可以使用命令行访问或客户端软件访问。

**命 令 行 访 问 方 式**

mysql -u 用户名 -p 密码 -hmycat主机IP -P8066
链接成功后，可以当做 MySQL 数据库使用。访问成功后，不能直接使用。因为 Mycat 只能访问 MySQL 的 schema（database），不能自动创建逻辑库对应的物理库。且不能自动创建逻辑表对应的物理表。必须人工链接 master 数据库，手动创建 database。
表格可以在 mycat 控制台创建。注意：在 mycat 控制台创建的表，必须是 schema.xml 配置文件中定义过的逻辑表。
启动后，经过测试，crc32slot 分片规则无效，执行 DML 语句的时候只能识别 db1 和 db2。DDL 语句，可以识别 db3。修改 conf/rule.xml 配置文件，找标签

```xml
<function name="crc32slot" class="io.mycat.route.function.PartitionByCRC32PreSlot">
    <property name="count">2</property>
    <!-- 要分片的数据库节点数量，必须指定，否则没法分片 -->
</function>
```

修改 count 参数。修改为对应的物理 database 数量，并删除mycat目录下conf/ruledata（存放的规则文件），重新启动。

### 9.访 问 约 束

**表 约 束**

不能创建未在 schema.xml 中配置的逻辑表

**DML  约 束**

尤其是新增: 必须在 insert into 语法后携带所有的字段名称.至少携带主键名称.
因为分片规则,绝大多数都是通过主键字段计算数据分片规则的.

### 10.查看 Mycat 日志

logs/wrapper.log
日志中记录的是所有的 mycat 操作. 查看的时候主要看异常信息 caused by 信息

## 三、测试

### 1.修改配置文件schema.xml

修改配置文件中`<schema>`、`<writeHost>`
  
```xml  
<?xml version="1.0"?>  
<!DOCTYPE mycat:schema SYSTEM "schema.dtd">  
<mycat:schema xmlns:mycat="http://io.mycat/">  
  
	<schema name="TESTDB" checkSQLschema="false" sqlMaxLimit="100">  
		<table name="tb_user" dataNode="dn1,dn2,dn3" rule="crc32slot" />  
	</schema>  
	<dataNode name="dn1" dataHost="localhost1" database="db1" />  
	<dataNode name="dn2" dataHost="localhost1" database="db2" />  
	<dataNode name="dn3" dataHost="localhost1" database="db3" />  
    
	<dataHost name="localhost1" maxCon="1000" minCon="10" balance="0" writeType="0" dbType="mysql" dbDriver="native" switchType="1"  slaveThreshold="100">  
 	<heartbeat>select user()</heartbeat>  
 		<writeHost host="hostM1" url="59.69.165.38:3306" user="root" password="123456">  
 		</writeHost> 
 	</dataHost>  
</mycat:schema>  
```

修改 conf/rule.xml 配置文件，找标签

```xml
<function name="crc32slot" class="io.mycat.route.function.PartitionByCRC32PreSlot">
    <property name="count">2</property>
    <!-- 要分片的数据库节点数量，必须指定，否则没法分片 -->
</function>
```

修改 count 参数。修改为对应的物理 database 数量为3，并删除mycat目录下conf/ruledata（缓存的规则文件），重新启动mycat：`bin/mycat restart`。

### 2.建表、插入SQL

客户端登录mycat：mysql -u root -p 123456 -h59.69.165.38 -P8066

```sql
create table tb_user(
    id int not null ,
    name varchar(32),
    password varchar(32),
    primary key (id)
);
insert into tb_user(id, name) values(1, 'aaa');
insert into tb_user(id, name) values(2, 'bbb');
insert into tb_user(id, name) values(3, 'ccc');
insert into tb_user(id, name) values(4, 'ddd');
insert into tb_user(id, name) values(5, 'eee');
insert into tb_user(id, name) values(6, 'aaa');
insert into tb_user(id, name) values(7, 'bbb');
insert into tb_user(id, name) values(8, 'ccc');
insert into tb_user(id, name) values(9, 'ddd');
insert into tb_user(id, name) values(10, 'eee');
insert into tb_user(id, name) values(11, 'aaa');
insert into tb_user(id, name) values(12, 'bbb');
```

### 3.查询

登录主库master，查询
```sql
mysql -uroot -p123456
select * from db1.tb_user;
select * from db2.tb_user;
select * from db3.tb_user;
```
## 四、MyCat  读写分离配置  
  
修改 conf/schema.xml 配置文件。  

关键在`balance="1"`，`<readHost host="hostS1" url="59.69.165.50:3306" user="root" password="123456" />`
  
```xml  
<?xml version="1.0"?>  
<!DOCTYPE mycat:schema SYSTEM "schema.dtd">  
<mycat:schema xmlns:mycat="http://io.mycat/">  
  
	<schema name="TESTDB" checkSQLschema="false" sqlMaxLimit="100">  
	<table name="tb_user" dataNode="dn1,dn2,dn3" rule="crc32slot" />  
	</schema>  
	<dataNode name="dn1" dataHost="localhost1" database="db1" />  
	<dataNode name="dn2" dataHost="localhost1" database="db2" />  
	<dataNode name="dn3" dataHost="localhost1" database="db3" />  
    
	<dataHost name="localhost1" maxCon="1000" minCon="10" balance="1" writeType="0" dbType="mysql" dbDriver="native" switchType="1"  slaveThreshold="100">  
		<heartbeat>select user()</heartbeat>  
		<writeHost host="hostM1" url="59.69.165.38:3306" user="root" password="123456">  
			<readHost host="hostS1" url="59.69.165.50:3306" user="root" password="123456" />
		</writeHost>
 	</dataHost>  
</mycat:schema>  
```
