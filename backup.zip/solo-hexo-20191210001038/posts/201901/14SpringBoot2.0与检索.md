title: （14）Spring Boot2.0 与检索
date: '2019-01-15 15:13:14'
updated: '2019-10-15 17:45:04'
tags: [JavaWeb, Springboot, 检索]
permalink: /articles/2019/01/15/1547536394012.html
---
![](https://img.hacpai.com/bing/20181105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**示例源码下载：[https://github.com/AlgerFan/springBootExample](https://github.com/AlgerFan/springBootExample) ，欢迎star。**

## 一、检索

我们的应用经常需要添加检索功能，开源的 [ElasticSearch](https://www.elastic.co/) 是目前全文搜索引擎的首选。他可以快速的存储、搜索和分析海量数据。Spring Boot通过整合Spring Data ElasticSearch为我们提供了非常便捷的检索功能支持；

Elasticsearch是一个分布式搜索服务，提供Restful API，底层基于Lucene，采用多shard（分片）的方式保证数据安全，并且提供自动resharding的功能，github等大型的站点也是采用了ElasticSearch作为其搜索服务。

## 二、概念

* 关于安装这里不做介绍。
* 入门练习：[官方文档](https://www.elastic.co/guide/cn/elasticsearch/guide/current/index.html)
* 以 员工文档 的形式存储为例：一个文档代表一个员工数据。存储数据到 ElasticSearch 的行为叫做索引 ，但在索引一个文档之前，需要确定将文档存储在哪里。
* 一个 ElasticSearch 集群可以 包含多个索引，相应的每个索引可以包含多个类型。 这些不同的类型存储着多个文档，每个文档又有 多个属性。
* 类似关系：
    * 索引-数据库
    * 类型-表
    * 文档-表中的记录
    * 属性-列
* SpringBoot默认支持两种技术来和ES交互。

![elastic01.png](https://img.algerfan.cn/blog/image/20190918/2a3d18e8d52a4ac3890396ebffd0c45f.png)

## 三、整合Jest操作ES

* 引入依赖

  ```xml
  <!-- springboot版本 1.5.12.RELEASE -->
  <dependency>
  	<groupId>io.searchbox</groupId>
  	<artifactId>jest</artifactId>
  	<version>5.3.3</version>
  </dependency>
  ```

* application.yml配置

  `spring.elasticsearch.jest.uris=http://algerfan.cn:9200`

* 测试

  ```java
  	@Autowired
      JestClient jestClient;
  
      @Test
      public void contextLoads() {
          Article article = new Article(1, "张三", "好文章", "今天是美好的一天");
          Index build = new Index.Builder(article).index("algerfan").type("news").build();
          try {
              //执行
              jestClient.execute(build);
          } catch (IOException e) {
              e.printStackTrace();
          }
      }
  ```

  浏览器访问：http://IP地址:9200/algerfan/news/1，即可看到存入的数据。

   ```java
  	@Test
      public void search() {
          //查询表达式
          String json = "{\n" +
                  "    \"query\" : {\n" +
                  "        \"match\" : {\n" +
                  "            \"content\" : \"美好的一天\"\n" +
                  "        }\n" +
                  "    }\n" +
                  "}";
          //更多操作：https://github.com/searchbox-io/Jest/tree/master/jest
          //构建搜索功能
          Search build = new Search.Builder(json).addIndex("algerfan").addType("news").build();
          try {
              //执行
              SearchResult execute = jestClient.execute(build);
              System.out.println(execute.getJsonString());
              System.out.println(execute.getMaxScore());
          } catch (IOException e) {
              e.printStackTrace();
          }
      }
   ```

## 四、整合ElasticSearch

* 引入spring-boot-starter-data-elasticsearch，这里一定注意版本，之前的文章中我使用的是springboot2.0.2.RELEASE，由于无法导入ElasticSearch，因此这次使用了`springboot1.5.12.RELEASE`，切换为默认的maven仓库，不要使用阿里云仓库。

  ```xml
  <!-- 导入ElasticSearch依赖 -->
  <dependency>
      <groupId>org.springframework.boot</groupId>
      <artifactId>spring-boot-starter-data-elasticsearch</artifactId>
  </dependency>
  ```

* 另外SpringData ElasticSearch【ES版本有可能不合适，这里降低版本为2.4.6】
  
  * 版本适配说明：https://github.com/spring-projects/spring-data-elasticsearch
  *  如果版本不适配：2.4.6        1）升级SpringBoot版本        2）安装对应版本的ES
  
* application.yml配置
  
  ```properties
  spring.data.elasticsearch.cluster-name=elasticsearch
  # 这里使用的docker内部端口为9300
  spring.data.elasticsearch.cluster-nodes=algerfan.cn:9300
  ```
  
* 两种用法：https://github.com/spring-projects/spring-data-elasticsearch
  
* 测试ElasticSearch

  1）编写一个 ElasticsearchRepository

  ```java
  @Document(indexName = "algerfan",type = "book")
  public class Book {
      private Integer id;
      private String bookName;
      private String author;
  
      public Integer getId() {
          return id;
      }
  
      public void setId(Integer id) {
          this.id = id;
      }
  
      public String getBookName() {
          return bookName;
      }
  
      public void setBookName(String bookName) {
          this.bookName = bookName;
      }
  
      public String getAuthor() {
          return author;
      }
  
      public void setAuthor(String author) {
          this.author = author;
      }
      
      public Book(){}
      
      public Book(Integer id, String bookName, String author) {
          this.id = id;
          this.bookName = bookName;
          this.author = author;
      }
  
      @Override
      public String toString() {
          return "Book{" +
                  "id=" + id +
                  ", bookName='" + bookName + '\'' +
                  ", author='" + author + '\'' +
                  '}';
      }
  }
  ```

  ```java
  public interface BookRepository extends ElasticsearchRepository<Book,Integer> {
  
      List<Book> findByBookNameLike(String bookName);
  
  }
  ```

  2）测试

  ```java
  	@Autowired
      BookRepository bookRepository;
  
      @Test
      public void test(){
  		Book book = new Book(1, "深入理解Java虚拟机", "周志明");
          bookRepository.index(book);
  
          for (Book book1 : bookRepository.findByBookNameLike("虚拟机")) {
              System.out.println(book1);
          }
      }
  ```

  3）更多使用方法：https://docs.spring.io/spring-data/elasticsearch/docs/3.0.6.RELEASE/reference/html/
