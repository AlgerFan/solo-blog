title: 小技巧：GitHub迁移至码云、码云迁移至GitHub（保留历史commit记录）
date: '2019-10-03 11:32:47'
updated: '2019-10-29 20:55:08'
tags: [GitHub]
permalink: /articles/2019/10/03/1570073567013.html
---
![](https://img.hacpai.com/bing/20180101.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

有没有想过迁移Git，并且保留历史commit记录，这是我无意间发现的一个小技巧，适用于码云、GitHub、coding等等更多自行尝试。

## 第一步：码云新建仓库

填写仓库名称，其他什么都不用填，不创建任何文件，这样保证git commit历史不冲突

## 第二步：GitHub拉取代码

修改.git目录下的config文件，替换url地址，如图：

![Git迁移2.png](https://img.algerfan.cn/blog/image/20191003/a31e382f1df7499da92f313b7a519db6.png)

## 第三步：push代码

直接git push，成功后就会发现保留了历史commit记录。

![Git迁移3.png](https://img.algerfan.cn/blog/image/20191003/dd91cef693754ac0ad5f04506dc3892b.png)

![Git迁移1.png](https://img.algerfan.cn/blog/image/20191003/cdb65b18570f4b479bf2ca7c13e58a11.png)
