title: Java基础练习题三（面向对象，集合的List、Set、Map）
date: '2018-12-11 03:24:31'
updated: '2019-09-01 09:01:49'
tags: [JavaSE]
permalink: /articles/2018/12/11/1544469871012.html
---
以下为java入门的一些练习题，给大一出的考核题、特在此总结一下，主要包含面向对象，集合（List、Set、Map）

#### 一、 简答题

1.	HTTP服务默认端口号和SSH服务默认端口号分别为多少？

	`HTTP服务默认端口号为80，SSH服务默认端口号为22`

2.	TCP/IP网络参考模型包括哪几个层次？

	`应用层、传输层、网络层、链路层`

3.	说明TCP/IP中，URL的概念及其组成。

```text
	URL是统一资源定位器的英文缩写，它表示Internet上某一资源的地址。
	URL由传输协议、主机名、	端口号、文件名、引用5部分组成。
```

4. TCP和UDP的区别（从是否连接、传输可靠性、应用场合、速度方面简要回答）

```text
	TCP 	      UDP 
	是否连接   	面向连接      面向非连接 
	传输可靠性   可靠          不可靠 
	应用场合     传输大量数据  少量数据 
	速度         慢            快	
```

#### 二、 编程题

##### 1.	 按题目要求实现以下功能

- 1）	 定义一个Human类，含有成员姓名name、性别sex、年龄age。
- 2）	定义一个Professor类，继承自Human类，该类是教师的蓝图
	a)	成员属性： 
	i.	讲授课程course 
	ii.	教学效果result 该属性的取值为 0-3。（1表示效果良好，2表示可以接受，3表示效果不佳，0表示未予评价）
	b)	构造方法： Professor用于设置姓名、性别、年龄和讲授课程。 
	c)	成员方法： 
	i.	getDetails 该方法将姓名、性别、年龄和讲授课程属性以字符串方式返回。 
	ii.	setResult 该方法用于设置教学效果， 必须考虑设置是否合理 （若不是 0-3 之间，则不允许设置）。
	iii.	getResult该方法返回教学效果。
- 3）	编写测试类测试
	a)	创建两个Professor类professor1和professor2，分别设置姓名，性别、年龄和讲授课程并输出。
	b)	professor1和professor2设置教学效果，并比较是否相等，相等输出YES，否则输出NO。


```java

/**
 * @author AlgerFan
 * @date Created in 2018/12/6 21
 * @Description 第一题
 */

public class test {
    public static void main(String[] args) {
        Professor professor1 = new Professor("测试1","男",30,"Java程序设计");
        Professor professor2 = new Professor("测试2","男",37,"体育");
        System.out.println(professor1.getDetails());
        System.out.println(professor2.getDetails());
        if(professor1.setResult(1)){
            System.out.println("professor1设置教学效果成功");
        } else {
            System.out.println("professor1设置教学效果失败");
        }
        if(professor1.setResult(2)){
            System.out.println("professor2设置教学效果成功");
        } else {
            System.out.println("professor2设置教学效果失败");
        }
        if(professor1.getResult().equals(professor2.getResult())){
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }
}

class Human {
    /**
     * 姓名
     */
    public String name;
    /**
     * 性别
     */
    public String sex;
    /**
     * 年龄
     */
    public int age;
}

class Professor extends Human {
    /**
     * 讲授课程
     */
    private String course;
    /**
     * 教学效果  1表示效果良好，2表示可以接受，3表示效果不佳，0表示未予评价
     */
    private int result;

    public Professor(String name, String sex, int age, String course){
        this.name = name;
        this.sex = sex;
        this.age = age;
        this.course = course;
    }

    public String getDetails() {
        return "姓名："+name+" 性别："+sex+" 年龄："+age+" 讲授课程："+course;
    }

    public boolean setResult(int result) {
        if(result >= 0 && result <= 3){
            this.result = result;
            return true;
        } else {
            return false;
        }
    }

    public String getResult() {
        if(result == 0){
            return "未予评价";
        } else if(result == 1) {
            return "效果良好";
        } else if(result == 2){
            return "可以接受";
        } else {
            return "效果不佳";
        }
    }

}

```

##### 2.	创建一个课程类Course，成员有课程编号id、课程名称courseName、课程学时school、课程学分credits，编写构造方法Course用于设置课程编号、课程名称和课程学时，编写getter和setter方法用于获取和设置类中各变量的值，编写toString方法，返回课程的所有信息。

- a)  创建一个泛型为Course的List集合，添加六个对象，分别为(1,"大学高数",64,4)、(2,"大学体育",36,1)、(3,"Java程序设计",48,3)、(4,"英语读写AI",32,2)、(4,"英语读写AI",32,2)、(5,"形式与政策",96,2)，其中添加的课程编号为4的课程为同一个对象，便于第2小题的使用，要求使用for循环输出学分大于2的课程。
- b) 对第一题的List集合进行去重，并输出去重后的课程。
- c) 利用迭代器将第一题中学时大于49的课程进行删除，并输出删除后的结果。
- d) 修改map中的元素，要求将第一题的List集合转换为map集合，key值为课程编号id，输入一个课程编号，判断该门课程是否存在，若存在则修改这门课程的学时，并输出修改后的课程信息，若不存在则重新输入课程编号。

```java
import java.util.*;

/**
 * @author AlgerFan
 * @date Created in 2018/12/6 22
 * @Description 第二题
 */
class Course {
    /**
     * 课程编号
     */
    private int id;
    /**
     * 课程名称
     */
    private String courseName;
    /**
     * 课程学时
     */
    private int school;
    /**
     * 课程学分
     */
    private int credits;

    public Course(int id, String courseName, int school, int credits) {
        this.id = id;
        this.courseName = courseName;
        this.school = school;
        this.credits = credits;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getSchool() {
        return school;
    }

    public void setSchool(int school) {
        this.school = school;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    @Override
    public String toString() {
        return "Course{" +
                "id=" + id +
                ", courseName='" + courseName + '\'' +
                ", school=" + school +
                ", credits=" + credits +
                '}';
    }
}

public class test2 {
    public static void main(String[] args) {
        System.out.println("第一题：");
        List<Course> courses = new ArrayList<>();
        courses.add(new Course(1,"大学高数",64,4));
        courses.add(new Course(2,"大学体育",36,1));
        courses.add(new Course(3,"Java程序设计",48,3));
        Course course1 = new Course(4, "英语读写AI", 32, 2);
        courses.add(course1);
        courses.add(course1);
        courses.add(new Course(5,"形式与政策",96,2));
        for (Course course : courses) {
            if (course.getCredits() > 2) {
                System.out.print(course+" ");
            }
        }
        System.out.println();
        System.out.println("第二题：");
        Set<Course> set = new HashSet<Course>(courses);
        for (Course course : set) {
            System.out.print(course+" ");
        }
        System.out.println();
        System.out.println("第三题：");
        Iterator<Course> it = courses.iterator();
        while (it.hasNext()){
            if(it.next().getSchool() > 49){
                it.remove();
            }
        }
        for (Course course : courses) {
            System.out.print(course+" ");
        }
        System.out.println();
        System.out.println("第四题：");
        Map<Integer,Course> courseMap = new HashMap<>();
        for (Course course : courses) {
            courseMap.put(course.getId(), course);
        }
        System.out.println("请输入需要修改的课程编号id");
        Scanner scanner = new Scanner(System.in);
        while (true) {
            int id = scanner.nextInt();
            //根据指定的key值获取Value值
            Course course = courseMap.get(id);
            if(course==null) {
                System.out.println("您需要修改的课程信息不存在,请重新输入");
            } else {
                System.out.println("您需要修改的课程学时为"+course.getSchool());
                System.out.println("请输入新的课程学时");
                int newSchool = scanner.nextInt();
                Course newStudent = new Course(id, course.getCourseName(), newSchool, course.getCredits());
                courseMap.put(id, newStudent);
                System.out.println("修改成功");
                break;
            }
        }
        System.out.println("该课程修改后为："+ courseMap.get(2));

    }
}

```

#### 进阶

定义两个数组，编写一个函数来计算它们的交集。示例 ：nums1[] = {4,9,5}, nums2[] = {9,4,9,8,4} 输出交集: [9,4]。（输出结果中的每个元素一定是唯一的，不考虑输出结果的顺序。）

```java
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * @author AlgerFan
 * @date Created in 2018/12/8 08
 * @Description 附加题
 */
public class test3 {
    public static void main(String[] args) {
        int[] num1 = {1,2,2,1,5,5,6,3,7,9,8};
        int[] num2 = {1,2,2,1,5,5,16,13,10,9,8};
        Set<Integer> hashSet = new HashSet<>();
        Set<Integer> integers = new HashSet<>();
        for (int aNum1 : num1) {
            hashSet.add(aNum1);
        }
        for (int aNum2 : num2) {
            if (hashSet.contains(aNum2)) {
                integers.add(aNum2);
            }
        }
        Iterator<Integer> it = integers.iterator();
        while (it.hasNext()){
            System.out.print(it.next()+" ");
        }
    }
}

```
