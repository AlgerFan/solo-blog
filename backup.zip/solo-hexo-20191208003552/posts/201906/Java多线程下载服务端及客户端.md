title: Java多线程下载——服务端及客户端
date: '2019-06-10 01:00:31'
updated: '2019-09-26 08:20:34'
tags: [JavaWeb, 多线程下载]
permalink: /articles/2019/06/10/1560099631012.html
---
![](https://img.hacpai.com/bing/20190613.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 服务端支持多线程下载

- controller层

```java

    /**
     * 多线程文件下载
     * @param filename
     * @return
     */
    @GetMapping("/files/{filename:.+}")
    @ResponseBody
    public ResponseEntity<Resource> serveFile(@PathVariable String filename) {
        Resource file = propertiesService.loadAsResource(filename);
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + file.getFilename() + "\"").body(file);
    }

```

- service层

```java

    @Override
    public Resource loadAsResource(String filename) {
        Path rootLocation = Paths.get(filePath +"/");
		//filePath为我的文件路径前缀，例如：D:\project
        try {
            Path file = rootLocation.resolve(filename);
            Resource resource = new UrlResource(file.toUri());
            if (resource.exists() || resource.isReadable()) {
                return resource;
            } else {
                log.info("Could not read file: " + filename);
            }
        } catch (MalformedURLException e) {
            log.info("Could not read file: " + filename);
        }
        return null;
    }

```

### 客户端下载实现

- 思路

&emsp;&emsp;多线程下载不仅需要客户端的支持，也需要服务端的支持。 conn.setRequestProperty("Range", "bytes=" + startIndex + "-" + endIndex);Range响应头是多线程下载分割的关键所在。

&emsp;&emsp;下载思路：首先判断下载文件大小，配合多线程分割定制http请求数量和请求内容，响应到写入到RandomAccessFile指定位置中。在俗点就是大的http分割成一个个小的http请求，相当于每次请求一个网页。RandomAccessFile文件随机类，可以向文件写入指定位置的流信息。

- 启动入口

```java

import java.util.Scanner;
import java.util.concurrent.TimeUnit;

/**
 * <p>
 *  启动入口
 * </p>
 *
 * @author algerfan
 * @since 2019/6/9 17
 */
public class DownloadMain {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入下载文件的地址，按ENTER结束");
        String downloadPath = scanner.nextLine();
        System.out.println("下载的文件名及路径为：" + MultiPartDownLoad.downLoad(downloadPath));
        try {
            System.out.println("下载完成，本窗口5s之后自动关闭");
            TimeUnit.SECONDS.sleep(5);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.exit(0);
    }
}

```

- 客户端线程池Constans类

```java

import java.util.concurrent.*;

/**
 * <p>
 *  客户端线程池Constans类
 * </p>
 *
 * @author algerfan
 * @since 2019/6/9 17
 */
public class Constans {
    public static final int MAX_THREAD_COUNT = getSystemProcessCount();
    private static final int MAX_IMUMPOOLSIZE = MAX_THREAD_COUNT;

    /**
     * 自定义线程池
     */
    private static ExecutorService MY_THREAD_POOL;
    /**
     * 自定义线程池
     */
    public static ExecutorService getMyThreadPool(){
        if(MY_THREAD_POOL == null) {
            MY_THREAD_POOL = Executors.newFixedThreadPool(MAX_IMUMPOOLSIZE);
        }
        return MY_THREAD_POOL;
    }

    /**
     * 线程池
     */
    private static ThreadPoolExecutor threadPool;

    /**
     * 单例，单任务 线程池
     * @return
     */
    public static ThreadPoolExecutor getThreadPool(){
        if(threadPool == null){
            threadPool = new ThreadPoolExecutor(MAX_IMUMPOOLSIZE, MAX_IMUMPOOLSIZE, 3, TimeUnit.SECONDS,
                    new ArrayBlockingQueue<>(16),
                    new ThreadPoolExecutor.CallerRunsPolicy()
            );
        }
        return threadPool;
    }

    /**
     * 获取服务器cpu核数
     * @return
     */
    private static int getSystemProcessCount(){
        return Runtime.getRuntime().availableProcessors();
    }

}


```

- 客户端多线程下载类MultiPartDownLoad

```java

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.locks.ReentrantLock;

 /**
 * <p>
 *  客户端多线程下载类
 * </p>
 *
 * @author algerfan
 * @since 2019/6/9 17
 */
public class MultiPartDownLoad {

    /**
     * 线程下载成功标志
     */
    private static int flag = 0;

    /**
     * 服务器请求路径
     */
    private String serverPath;
    /**
     * 本地路径
     */
    private String localPath;
    /**
     * 线程计数同步辅助
     */
    private CountDownLatch latch;
    /**
     * 定长线程池
     */
    private static ExecutorService threadPool;

    public MultiPartDownLoad(String serverPath, String localPath) {
        this.serverPath = serverPath;
        this.localPath = localPath;
    }

    public boolean executeDownLoad() {
        try {
            URL url = new URL(serverPath);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            //设置超时时间
            conn.setConnectTimeout(5000);
            //设置请求方式
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Connection", "Keep-Alive");
            int code = conn.getResponseCode();
            if (code != 200) {
                System.out.println(String.format("无效网络地址：%s", serverPath));
                return false;
            }
            //服务器返回的数据的长度，实际上就是文件的长度,单位是字节
            // int length = conn.getContentLength();  //文件超过2G会有问题
            long length = getRemoteFileSize(serverPath);

            System.out.println("文件总长度:" + length + "字节(B)");
            RandomAccessFile raf = new RandomAccessFile(localPath, "rwd");
            //指定创建的文件的长度
            raf.setLength(length);
            raf.close();
            //分割文件
            int partCount = Constans.MAX_THREAD_COUNT;
            int partSize = (int)(length / partCount);
            latch = new CountDownLatch(partCount);
            threadPool = Constans.getMyThreadPool();
            for (int threadId = 1; threadId <= partCount; threadId++) {
                // 每一个线程下载的开始位置
                long startIndex = (threadId - 1) * partSize;
                // 每一个线程下载的开始位置
                long endIndex = startIndex + partSize - 1;
                if (threadId == partCount) {
                    //最后一个线程下载的长度稍微长一点
                    endIndex = length;
                }
                System.out.println("线程" + threadId + "下载:" + startIndex + "字节~" + endIndex + "字节");
                threadPool.execute(new DownLoadThread(threadId, startIndex, endIndex, latch));
            }
            latch.await();
            if(flag == 0){
                return true;
            }
        } catch (Exception e) {
            System.out.println("文件下载失败");
        }
        return false;
    }


    /**
     * 内部类用于实现下载
     */
    public class DownLoadThread implements Runnable {

        /**
         * 线程ID
         */
        private int threadId;
        /**
         * 下载起始位置
         */
        private long startIndex;
        /**
         * 下载结束位置
         */
        private long endIndex;

        private CountDownLatch latch;

        DownLoadThread(int threadId, long startIndex, long endIndex, CountDownLatch latch) {
            this.threadId = threadId;
            this.startIndex = startIndex;
            this.endIndex = endIndex;
            this.latch = latch;
        }

        @Override
        public void run() {
            try {
                System.out.println("线程" + threadId + "正在下载...");
                URL url = new URL(serverPath);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestMethod("GET");
                //请求服务器下载部分的文件的指定位置
                conn.setRequestProperty("Range", "bytes=" + startIndex + "-" + endIndex);
                conn.setConnectTimeout(5000);
                int code = conn.getResponseCode();
                System.out.println("线程" + threadId + "请求返回code=" + code);
                //返回资源
                InputStream is = conn.getInputStream();
                RandomAccessFile raf = new RandomAccessFile(localPath, "rwd");
                //随机写文件的时候从哪个位置开始写
                //定位文件
                raf.seek(startIndex);
                int len;
                byte[] buffer = new byte[1024];
                while ((len = is.read(buffer)) != -1) {
                    raf.write(buffer, 0, len);
                }
                is.close();
                raf.close();
                System.out.println("线程" + threadId + "下载完毕");
            } catch (Exception e) {
                //线程下载出错
                MultiPartDownLoad.flag = 1;
				System.out.println("线程下载出错");
            } finally {
                //计数值减一
                latch.countDown();
            }

        }
    }

    /**
     * 内部方法，获取远程文件大小
     * @param remoteFileUrl
     * @return
     * @throws IOException
     */
    private long getRemoteFileSize(String remoteFileUrl) throws IOException {
        long fileSize;
        HttpURLConnection httpConnection = (HttpURLConnection) new URL(remoteFileUrl).openConnection();
        httpConnection.setRequestMethod("HEAD");
        int responseCode = 0;
        try {
            responseCode = httpConnection.getResponseCode();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (responseCode >= 400) {
            System.out.println("Web服务器响应错误!");
            return 0;
        }
        String sHeader;
        for (int i = 1;; i++) {
            sHeader = httpConnection.getHeaderFieldKey(i);
            if ("Content-Length".equals(sHeader)) {
                fileSize = Long.parseLong(httpConnection.getHeaderField(sHeader));
                break;
            }
        }
        return fileSize;
    }

    /**
     * 下载文件执行器
     * @param serverPath
     * @return
     */
    public synchronized static String downLoad(String serverPath) {
        ReentrantLock lock = new ReentrantLock();
        lock.lock();

        String[] names = serverPath.split("\\.");
        if (names.length <= 0) {
            return null;
        }
        String fileTypeName = names[names.length - 1];
        String localPath = String.format("/%s.%s", UUID.randomUUID(),fileTypeName);
        MultiPartDownLoad m = new MultiPartDownLoad(serverPath, localPath);
        long startTime = System.currentTimeMillis();
        boolean flag = false;
        try{
            flag = m.executeDownLoad();
            long endTime = System.currentTimeMillis();
            if(flag){
                System.out.println("文件下载结束,共耗时" + (endTime - startTime)+ "ms");
                return localPath;
            }
            System.out.println("文件下载失败");
            return null;
        }catch (Exception ex){
			System.out.println("文件下载失败");
            return null;
        }finally {
            // 重置 下载状态
            MultiPartDownLoad.flag = 0;
            if(!flag){
                File file = new File(localPath);
                file.delete();
            }
            lock.unlock();
        }
    }
}

```
