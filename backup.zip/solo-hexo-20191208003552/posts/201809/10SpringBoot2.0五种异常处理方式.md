title: （10）Spring Boot2.0 五种异常处理方式
date: '2018-09-13 09:40:14'
updated: '2019-09-25 22:44:12'
tags: [JavaWeb, Springboot, 异常处理]
permalink: /articles/2018/09/13/1536802814012.html
---
![](https://img.hacpai.com/bing/20180705.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**示例源码下载：[https://github.com/AlgerFan/springBootExample](https://github.com/AlgerFan/springBootExample) ，欢迎star。**

### 一、前言

  使用springboot也很长时间了，也做过几个小项目，最近有时间总结一下，话不多说，本篇介绍一下springboot提供的五种异常处理方式，下面直接代码演示

### 二、代码演示

1. 自定义错误页面
  SpringBoot默认已经提供了一套处理异常的机制。一旦程序中出现了异常SpringBoot会向/error的url发送请求。BasicExceptionController来处理该请求，然后跳转到默认显示异常的页面。
  当我们需要将所有异常统一跳转到一个页面的时候可以使用该方式，自定义错误页面的方式很简单，在src/main/resources/templates目录下创建error.html页面。注意：名称必须叫error。

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>错误提示页面</title>
</head>
<body>
	出错了，请与管理员联系。
</body>
</html>
```

2. @ExceptionHandle注解处理异常
  第一种方式所有的异常只能跳转到一个页面，并不实用，而@ExceptionHandle注解可以做到将我们关心的异常跳转到指定页面，以下代码演示：

Controller

```java
/**
 * @author AlgerFan
 * @date Created in 2019/1/25 16
 * @Description SpringBoot处理异常方式二：@ExceptionHandle注解处理异常
 */
@Controller
public class TestController {
	
	@RequestMapping("/show")
	public String showInfo(){
		String str = null;
		str.length();
		return "index";
	}

	/**
	 * java.lang.NullPointerException
	 */
	@ExceptionHandler(value={java.lang.NullPointerException.class})
	public ModelAndView nullPointerExceptionHandler(Exception e){
		ModelAndView mv = new ModelAndView();
		mv.addObject("error", e.toString());
		mv.setViewName("error1");
		return mv;
	}

}
```

HTML

```html
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"
	  xmlns:th="http://www.thymeleaf.org"  lang="en">
<head>
<meta charset="UTF-8">
<title>错误提示页面-ArithmeticException</title>
</head>
<body>
	出错了，请与管理员联系。
	<span th:text="${error}"></span>
</body>
</html>
```

3. @ControllerAdvice+@ExceptionHandler注解处理异常

  第二种方法并不是全局的，当然，有办法解决，那就是使用@ControllerAdvice注解，将异常处理在一个地方统一处理，以下代码演示：

```java
/**
 * @author AlgerFan
 * @date Created in 2019/1/25 17
 * @Description 全局异常处理类
 */
@ControllerAdvice
public class GlobalException {
	/**
	 * java.lang.ArrayIndexOutOfBoundsException
	 */
	@ExceptionHandler(value={ArrayIndexOutOfBoundsException.class})
	public ModelAndView arithmeticExceptionHandler(Exception e){
		ModelAndView mv = new ModelAndView();
		mv.addObject("error", e.toString());
		mv.setViewName("error1");
		return mv;
	}
	
	/**
	 * java.lang.NullPointerException
	 */
	@ExceptionHandler(value={NullPointerException.class})
	public ModelAndView nullPointerExceptionHandler(Exception e){
		ModelAndView mv = new ModelAndView();
		mv.addObject("error", e.toString());
		mv.setViewName("error2");
		return mv;
	}
	
}

```

4. 配置SimpleMappingExceptionResolver处理异常

  第四种处理异常其实是对第三种的简化，不需要一个方法处理一个异常，但是缺点是不能传递异常对象信息，也就是不能够将异常类型显示在视图上，只能做异常与视图的映射，以下代码演示：

```java
/**
 * @author AlgerFan
 * @date Created in 2019/1/25 17
 * @Description SimpleMappingExceptionResolver全局异常处理
 */
@Configuration
public class ExceptionConfig {

    /**
     * 该方法必须要有返回值。返回值类型必须是：SimpleMappingExceptionResolver
     */
    @Bean
    public SimpleMappingExceptionResolver getSimpleMappingExceptionResolver(){
        SimpleMappingExceptionResolver resolver = new SimpleMappingExceptionResolver();
        Properties mappings = new Properties();
        /*
         * 参数一：异常的类型，注意必须是异常类型的全名   参数二：视图名称
         */
        mappings.put("java.lang.ArithmeticException", "error1");
        mappings.put("java.lang.NullPointerException","error2");
        //设置异常与视图映射信息的
        resolver.setExceptionMappings(mappings);
        return resolver;
    }
}
```

5. 自定义HandlerExceptionResolver类处理异常

  第五种是补上了第四种的缺点，既可以做异常与视图的映射，又可以传递异常对象信息，需要在全局异常处理类中实现HandlerExceptionResolver接口，以下演示代码：

```java
/**
 * @author AlgerFan
 * @date Created in 2019/1/25 18
 * @Description 通过实现HandlerExceptionResolver接口做全局异常处理
 */
@Configuration
public class GlobalException2 implements HandlerExceptionResolver {

    @Override
    public ModelAndView resolveException(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) {
        ModelAndView mv = new ModelAndView();
        //判断不同异常类型，做不同视图跳转
        if(e instanceof ArithmeticException){
            mv.setViewName("error1");
        }
        if(e instanceof NullPointerException){
            mv.setViewName("error2");
        }
        mv.addObject("error", e.toString());
        return mv;
    }
}

```
