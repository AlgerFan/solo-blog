title: LeetCode棒球比赛
date: '2018-08-18 23:35:12'
updated: '2019-07-21 09:39:56'
tags: [LeetCode]
permalink: /articles/2018/08/18/1534606512012.html
---
![](https://img.hacpai.com/bing/20180625.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

### 一、题目

[LeetCode地址](https://leetcode-cn.com/problems/plus-one/description/)

　    你现在是棒球比赛记录员。
　    给定一个字符串列表，每个字符串可以是以下四种类型之一：

　    1.整数（一轮的得分）：直接表示您在本轮中获得的积分数。

　    2. "+"（一轮的得分）：表示本轮获得的得分是前两轮有效 回合得分的总和。

　    3. "D"（一轮的得分）：表示本轮获得的得分是前一轮有效 回合得分的两倍。

　    4. "C"（一个操作，这不是一个回合的分数）：表示您获得的最后一个有效 回合的分数是无效的，应该被移除。
	

　    每一轮的操作都是永久性的，可能会对前一轮和后一轮产生影响。
　    你需要返回你在所有回合中得分的总和。
​	
　    示例 1:
​	

　    输入: ["5","2","C","D","+"]
　    输出: 30

　    解释: 
　    第1轮：你可以得到5分。总和是：5。
　    第2轮：你可以得到2分。总和是：7。
　    操作1：第2轮的数据无效。总和是：5。
　    第3轮：你可以得到10分（第2轮的数据已被删除）。总数是：15。
　    第4轮：你可以得到5 + 10 = 15分。总数是：30。

　    示例 2:
​	
　    输入: ["5","-2","4","C","D","9","+","+"]
　    输出: 27

　    解释: 
　    第1轮：你可以得到5分。总和是：5。
　    第2轮：你可以得到-2分。总数是：3。
　    第3轮：你可以得到4分。总和是：7。
　    操作1：第3轮的数据无效。总数是：3。
　    第4轮：你可以得到-4分（第三轮的数据已被删除）。总和是：-1。
　    第5轮：你可以得到9分。总数是：8。
　    第6轮：你可以得到-4 + 9 = 5分。总数是13。
　    第7轮：你可以得到9 + 5 = 14分。总数是27。

　    注意：
　    输入列表的大小将介于1和1000之间。
　    列表中的每个整数都将介于-30000和30000之间。

### 二、分析

　    该题用了栈的知识，因为之前很少接触，再次记录一下，题中主要用了Stack的几个方法，简单易懂，不做分析了

### 三、Java代码

```java
public static int calPoints(String[] ops) {
    int n = 0;
    Stack<Integer> stack = new Stack<>();
    for (String s:ops) {
        switch (s) {
            case "+":
                //stack.pop()删除堆栈顶部的对象并返回该对象
                int del = stack.pop();
                //stack.peek()返回堆栈顶部的对象
                int last = del + stack.peek();
                n += last;
                stack.push(del);
                stack.push(last);
                break;
            case "D":
                int twoLast = stack.peek() * 2;
                n += twoLast;
                //stack.push(twoLast)保存到堆栈
                stack.push(twoLast);
                break;
            case "C":
                n -= stack.pop();
                break;
            default:
                int save = Integer.parseInt(s);
                n += save;
                stack.push(save);
                break;
        }
    }
    return n;
}
```

### 四、提交结果

![682](https://img.algerfan.cn/blog/image/20190619/f9c1494cd76a4980b2a30dfd35bbc48c.png)